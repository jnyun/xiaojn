<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    />
     <!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
  </body>
</html>
   <title>小Jn帖子id获取工具</title>
  </head>
  <body>
       <body class="mdui-appbar-with-toolbar">
  <div class="mdui-appbar mdui-appbar-fixed mdui-appbar-scroll-hide">
    <div class="mdui-toolbar mdui-color-theme">
  <a href="javascript:window.history.back();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">keyboard_arrow_left</i></a>
  <span class="mdui-typo-title">小Jn帖子ID获取工具</span>
  <div class="mdui-toolbar-spacer"></div>
  
  

  <a href="javascript:location.reload();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">refresh</i></a>
<button class="mdui-btn mdui-btn-icon" mdui-menu="{target:'#main-menu'}"><i class="mdui-icon material-icons">more_vert</i></button>

<ul class="mdui-menu" id="main-menu">

              	<li class="mdui-menu-item" >
                	<a href="/tool.php" class="mdui-ripple">首页</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/jqrcz.php" class="mdui-ripple">批量管理</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/box.php" class="mdui-ripple">工具箱</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/site.php" class="mdui-ripple">分站</a>
              	</li>
            </ul>
  		</div>
	</div>
		<script src="./js/mdui.min.js"></script> 	  <script>     if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");      document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     );  </script><p id="switch-theme">>点此切换黑白</p> <script>      if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");           document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     ); </script><script type="text/javascript" src="https://s9.cnzz.com/z_stat.php?id=1279812358&web_id=1279812358"></script></a>               	</li>             </ul>   		</div> 	</div> 	
	<script src="./js/jquery.min.js"></script>
	<script type="text/javascript" charset="utf-8">
	  $(window).scroll(function(){
	    var scrollTop = $(window).scrollTop();
	   if (scrollTop < 100) {
	      $(".mdui-APPbar").removeClass("mdui-color-theme");
          $(".mdui-APPbar").addClass("mdui-text-color-black");
          $(".mdui-APPbar").removeClass("mdui-text-color-white")
	   } else {
	      $(".mdui-APPbar").addClass("mdui-text-color-white");
	      $(".mdui-APPbar").addClass("mdui-color-theme");
	      $(".mdui-APPbar").removeClass("mdui-text-color-black");
	   }
	  });
	</script>
<div class="mdui-panel" mdui-panel>



<h5>PS:获取的是你收藏夹的帖子(仅获取前10贴)</h5>

<?php
error_reporting(0);
    
$url="http://floor.huluxia.com/post/favorite/list/ANDROID/2.0?platform=2&gkey=000000&app_version=4.1.1.2.2&versioncode=318&market_id=tool_tencent&_key=".$_COOKIE["ekey"]."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&start=0&count=20&user_id=".$_COOKIE["uid"];
$pl=file_get_contents($url);
$jsonStr = $pl;

$arr = json_decode($pl,true);


for($i=0;$i<10;$i++)
{
//超级获取术
$pid=$arr["posts"][$i]["postID"];//postID
$bt=$arr["posts"][$i]["title"];//标题
$jj=$arr["posts"][$i]["detail"];//简介
$name=$arr["posts"][$i]["user"]["nick"];//昵称

echo
<<<EOF
<html>
 <head> 
  <title>帖子列表-JnAPI</title> 
  <meta charset="utf-8"> 
  <!--响应式--> 
 
 </head> 
 <ul class="mdui-list">
  <li class="mdui-list-item mdui-ripple">
  
 <body id="v1">
 <h1>帖子ID:$pid<script src="https://cdn.bootcss.com/clipboard.js/1.7.1/clipboard.min.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<div><span id="btn$pid" data-clipboard-text="$pid">点此复制</span></div>
<div id="show$pid" style="display: none;">已复制</div>
<script>
	var btn=document.getElementById('btn$pid');
	var clipboard=new Clipboard(btn);
	clipboard.on('success', function(e){
		$('#show$pid').slideDown().delay(1500).slideUp(300);
		console.log(e);
	});
	clipboard.on('error', function(e){
		$('#show').slideDown().delay(1500).slideUp(300);
		console.log(e);
	});
</script></h1>
  <p>作者:$name</p>
  <br>
  <h5 id="v2">简介:$bt</h5> 
  </br>
  <br>
  <h5>内容:$jj</h5>
  
  <li>
  

  
 </span></div></div></button> 
 </body>
</html>
EOF;
}
?>
</ul>