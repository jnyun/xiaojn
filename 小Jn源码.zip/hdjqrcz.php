<?php


if($_COOKIE["phone"]==null)
{
 echo '<script>window.alert("未登录！");</script>';
 
 Header("Location: /login.php");
  
 }?>


<!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>小Jn——活动管理</title>
	<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

<!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    />
    <body class="mdui-appbar-with-toolbar">
  <div class="mdui-appbar mdui-appbar-fixed mdui-appbar-scroll-hide">
    <div class="mdui-toolbar mdui-color-theme">
  <a href="javascript:window.history.back();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">keyboard_arrow_left</i></a>
  <span class="mdui-typo-title">小Jn</span>
  <div class="mdui-toolbar-spacer"></div>
  
  

  <a href="javascript:location.reload();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">refresh</i></a>
<button class="mdui-btn mdui-btn-icon" mdui-menu="{target:'#main-menu'}"><i class="mdui-icon material-icons">more_vert</i></button>

<ul class="mdui-menu" id="main-menu">

              	<li class="mdui-menu-item" >
                	<a href="/tool.php" class="mdui-ripple">首页</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/jqrcz.php" class="mdui-ripple">批量管理</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/box.php" class="mdui-ripple">工具箱</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/site.php" class="mdui-ripple">分站</a>
              	</li>
            </ul>
  		</div>
	</div>
		<script src="./js/mdui.min.js"></script> 	  <script>     if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");      document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     );  </script><p id="switch-theme">>点此切换黑白</p> <script>      if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");           document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     ); </script><script type="text/javascript" src="https://s9.cnzz.com/z_stat.php?id=1279812358&web_id=1279812358"></script></a>               	</li>             </ul>   		</div> 	</div> 	
	<script src="./js/jquery.min.js"></script>
	<script type="text/javascript" charset="utf-8">
	  $(window).scroll(function(){
	    var scrollTop = $(window).scrollTop();
	   if (scrollTop < 100) {
	      $(".mdui-APPbar").removeClass("mdui-color-theme");
          $(".mdui-APPbar").addClass("mdui-text-color-black");
          $(".mdui-APPbar").removeClass("mdui-text-color-white")
	   } else {
	      $(".mdui-APPbar").addClass("mdui-text-color-white");
	      $(".mdui-APPbar").addClass("mdui-color-theme");
	      $(".mdui-APPbar").removeClass("mdui-text-color-black");
	   }
	  });
	</script>

</div>
  </head><div class="mdui-ripple">
<div class="mdui-card">
  <div class="mdui-card-media">
    <img src="/card.webp"/>
    <div class="mdui-card-media-covered">
      <div class="mdui-card-primary">
        <div class="mdui-card-primary-title">欢迎回家</div>
        <div class="mdui-card-primary-subtitle"><?php  $userMsg=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/2.1?_key=".$_COOKIE["ekey"]."&user_id=".$_COOKIE["uid"]);
$user=json_decode($userMsg,true);

$namejn=$user["nick"];echo$namejn ;?></div>
      </div>
      <div class="mdui-card-actions">
        <a href="/addhd.php"<button class="mdui-btn mdui-ripple mdui-ripple-white">添加活动</button></a>
           <a href="/schdjqr.php" <button class="mdui-btn mdui-ripple mdui-ripple-white">一键全删</button></a>
      </div>
    </div>
  </div>
</div>
</div>





</body>

<!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
  
	<!--可无视-->
	<link rel="stylesheet" type="text/css" href="css/bootstrap-grid.min.css" /><!--CSS RESET-->

	
	<!--必要样式-->
	<link rel="stylesheet" href="css/naranja.min.css">
</head>
<body>
	  
<script>
  var tab = new mdui.Tab('#example4-tab');
  document.getElementById('example-4').addEventListener('open.mdui.dialog', function () {
    tab.handleUpdate();
  });
</script>
	<div class="container">
		<div class="row" style="padding:2em 0">
			<div class="col-md-2">
		
<div style="margin: 0 auto; width: 0%; position: fixed; bottom: 5px; height: 100％; font-size: 0; line-height: 0; z-index: 100; text-align: left;">

	
		</div></div>


 <?php
 

$dqdz=$_SERVER['HTTP_HOST'];
ini_set("error_reporting","E_ALL & ~E_NOTICE");

$phoneNumber=$_COOKIE["phone"];
$password=$_COOKIE["key"];
$r=$_COOKIE["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];

switch($msg)
{
  case "账号或密码错误":
    echo '<script>window.alert("账号或密码错误！");</script>';
    break;
  case "参数不合法":
    echo '<script>window.alert("参数不合法！");</script>';
    break;
  case "账号不存在":
    echo '<script>window.alert("账号不存在");</script>';
    break;
  case "":
    
     $filename2='jkkey/'.$uid.'.txt';

$jnx=file($filename2);

 $filename='hd/'.$uid.'.txt';
 $ex=file_exists($filename);//检测文件存在与否
if($ex==1)
{
$b=file($filename);
$c=count($b)/7;
$d=$c;
 echo"您当前有：".$c."个活动";
for($i=0;$i<$c;$i++)
{
    $jkkey=$jnx[0*$i];
$name=$b[7*$i];
$phone=$b[1+$i*7];
$n=substr($phone,0,strlen($phone)-1); 
$keyj=$b[7*$i+2];
$keyx = substr($keyj,0,strlen($keyj)-1); 
$gn=$b[7*$i+3];
$da=$b[7*$i+4];
$jnxiao=$b[7*$i+5];

  echo <<<EOF
  
<div class="mdui-card">

  
  <!-- 卡片的标题和副标题 -->
  <div class="mdui-card-primary">
    <div class="mdui-card-primary-title">活动帖子id:$name</div>
    <div class="mdui-card-primary-subtitle">功能：$gn</div>
  </div>

  <!-- 卡片的内容 -->
 
 
  <div class="mdui-card-actions">
     
    <button class="mdui-btn mdui-ripple"mdui-dialog="{target: '#example-4$i'}">后端运行</button>
    <a href="/tjsj.php?u=$uid&id=$i&jkkey=$jkkey" <button class="mdui-btn mdui-ripple mdui-ripple-white">查看统计数据</button></a>
    
    <div class="mdui-dialog" id="example-4$i">
  <div class="mdui-tab mdui-tab-full-width" id="example4-tab$i">
    <a href="#example4-tab1$i" class="mdui-ripple">监控接口</a>
    <a href="#example4-tab2$i" class="mdui-ripple">如何监控</a>
    <a href="#example4-tab3$i" class="mdui-ripple">赞助我们</a>
  </div>
  <div id="example4-tab1$i" class="mdui-p-a-2">
    <p>当前活动后端监控接口为
    <p>(也就是实现统计等功能的接口)</p>
    <p>http://$dqdz/hdjk.php?u=$uid&id=$i&jkkey=$jkkey</p>
    <p>挂上网址监控才可完成全自动化</p>
     
  </div>
  <div id="example4-tab2$i" class="mdui-p-a-2">
    <p>百度免费监控网，或者你直接用首页公告里我们官方的也行</p>
     <p>小Jn官方免费网址监控:<a href="http://www.xiaoman1221.top/">官方免费监控</a></p>
    <p>添加网址监控</p>
    <p>监控间隔即为回复间隔时间</p>
    <p>实在找不到的加官群</p>
    <p>我们给你挂</p>
 <br>        各位大佬你们挂监控正常一点
<br>1.不要把多个网址粘到一个编辑框里去
<br>2.不要把监控间隔设置在30秒以内
<br>以下是我们的建议间隔
<br>1.自动回复最好30到60秒
<br>2.自动签到最好2小时一次，记得换算单位
<br>3.自动乞讨顶帖之类的，就跟自动回复差不多好了
<br>4.自动水帖，你至少设置个10分钟间隔吧，要不然频繁发不出去的
<br>5.自动卖关注和自动回复一样，起码要30到60秒
<br>谢谢合作!!!!!＼（〇_ｏ）／
  </div>
  <div id="example4-tab3$i" class="mdui-p-a-2">
    <p>这个呀。。。</p>
    <p>发给群主就好了</p>
    <p>或者发给小狗杂也行</p>
    <p>官Q:1032050534</p>
     <p>欢迎⊙ω⊙</p>
      <p>。。。。。</p>
  </div>
</div>
<script>
  var tab = new mdui.Tab('#example4-tab$i');
  document.getElementById('example-4').addEventListener('open.mdui.dialog', function () {
    tab.handleUpdate();
  });
</script>
  <!-- 卡片头部，包含头像、标题、副标题 -->
  <div class="mdui-card-header">
    <img class="mdui-card-header-avatar" src="jqr2.png"/>
    <div class="mdui-card-header-title">答案：$da</div>
    <div class="mdui-card-header-subtitle">执行者:$phone</div>
  </div>

 

    <!-- 卡片中可以包含一个或多个菜单按钮 -->
   
  </div>

EOF;

}
}
else {
   echo
   <<<EOF
   <div class="mdui-card">
  <div class="mdui-card-media">
    <img src="xiaogz.jpg"/>
    <div class="mdui-card-media-covered mdui-card-media-covered-transparent">
      <div class="mdui-card-primary">
        <div class="mdui-card-primary-title"></div>
        <div class="mdui-card-primary-subtitle"></div>
      </div>
    </div>
  </div>
  <div class="mdui-center" style="width: 200px">大佬，你还一个活动都没有呢</div>
EOF;
    
    
}
}

break;

?>

    
  </div>
</div>




    
	</div>




</body>
</html>
