<?php
$phoneNumber=$_COOKIE["phone"];
$password=$_COOKIE["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];

$a=file_get_contents("http://floor.huluxia.com/credits/transfer/ANDROID/2.0?platform=2&gkey=000000&app_version=4.1.1.4.1&versioncode=325&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&phone_brand_type=HW&post_id=49349849&type_id=1&isadmin=0&score=5".'&score_txt=真666，爱了');
$b='{"msg":"","iscredits":1,"status":1}';
$js=json_decode($a,true);
$zt=$js["msg"];
if($zt==null)
{
    
    error_reporting(0);


   {  
       
     $filename='vip/'.$uid.'.txt';
     $ex=file_exists($filename);//检测文件存在与否
    if($ex==1)
{
 $f2=str_replace("\n","",file_get_contents($filename));
 
 


  
$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $a=date('Y-m-d', strtotime('+1 day', strtotime($f2))));//写入
fclose($myfile);
echo"会员续费成功，到期时间:".$a;

}
if($ex==0)
{
    
$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $a=date("Y-m-d",strtotime("+1 day")));//写入
fclose($myfile);
echo '开通会员成功，日费首次开通附赠0天（恭喜您成功失去首充送时长福利?），到期时间'.$a;
}
}
}
else{
    echo "兑换失败！原因：".$zt;
}
?>