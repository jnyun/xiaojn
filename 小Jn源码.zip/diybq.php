<title>小JnAPI实验室项目-DIY标签</title><?php

      if($_GET["bq"]!==null){
$x= file_get_contents("http://floor.huluxia.com/user/tag/set/ANDROID/2.1?platform=2&gkey=000000&app_version=3.5.0.82.1&versioncode=20141379&market_id=floor_web&_key=".$_COOKIE["ekey"]."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00-%5Bi%5D864032033634344-%5Bs%5D89860041191702746644&upload_tags=".$_GET["bq"]);
}if ($x=='{"msg":"","status":1}') {
    echo "修改成功，已生效";
}
else{echo"修改失败，修改格式错误!自己回去好好看清楚!";}
