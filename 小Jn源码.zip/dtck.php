
<?php
  ini_set("display_errors", "On");
    
 $filename='jndt.txt';
 $ex=file_exists($filename);//检测文件存在与否
if($ex==1)
{
$b=file_get_contents($filename);

$keyx=$b;

}
?>

<!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>小Jn——顶帖词库创建/编辑</title>
	<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

<!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    />
       <body class="mdui-appbar-with-toolbar">
  <div class="mdui-appbar mdui-appbar-fixed mdui-appbar-scroll-hide">
    <div class="mdui-toolbar mdui-color-theme">
  <a href="javascript:window.history.back();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">keyboard_arrow_left</i></a>
  <span class="mdui-typo-title">小Jn</span>
  <div class="mdui-toolbar-spacer"></div>
  
  

  <a href="javascript:location.reload();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">refresh</i></a>
<button class="mdui-btn mdui-btn-icon" mdui-menu="{target:'#main-menu'}"><i class="mdui-icon material-icons">more_vert</i></button>

<ul class="mdui-menu" id="main-menu">

              	<li class="mdui-menu-item" >
                	<a href="/tool.php" class="mdui-ripple">首页</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/jqrcz.php" class="mdui-ripple">批量管理</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/box.php" class="mdui-ripple">工具箱</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/site.php" class="mdui-ripple">分站</a>
              	</li>
            </ul>
  		</div>
	</div>
		<script src="./js/mdui.min.js"></script> 	  <script>     if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");      document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     );  </script><p id="switch-theme">>点此切换黑白</p> <script>      if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");           document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     ); </script><script type="text/javascript" src="https://s9.cnzz.com/z_stat.php?id=1279812358&web_id=1279812358"></script></a>               	</li>             </ul>   		</div> 	</div> 	
	<script src="./js/jquery.min.js"></script>
	<script type="text/javascript" charset="utf-8">
	  $(window).scroll(function(){
	    var scrollTop = $(window).scrollTop();
	   if (scrollTop < 100) {
	      $(".mdui-APPbar").removeClass("mdui-color-theme");
          $(".mdui-APPbar").addClass("mdui-text-color-black");
          $(".mdui-APPbar").removeClass("mdui-text-color-white")
	   } else {
	      $(".mdui-APPbar").addClass("mdui-text-color-white");
	      $(".mdui-APPbar").addClass("mdui-color-theme");
	      $(".mdui-APPbar").removeClass("mdui-text-color-black");
	   }
	  });
	</script>
  </head>
  <div class="mdui-ripple">
<div class="mdui-panel-item mdui-panel-item-open">
    <div class="mdui-panel-item-header">小Jn顶帖词库</div>
    <div class="mdui-panel-item-body">
    
       <p>填写格式</p>
       <p>每行一个</p>
</div>
  </div>


<form action ="ckdt.php" method ="get">

<div class="mdui-textfield">
  <i class="mdui-icon material-icons">account_circle</i>
  <label class="mdui-textfield-label">词库内容</label>
  <textarea name="txt" class="mdui-textfield-input" rows="10" placeholder="词库内容" type="text" value="<?php echo$keyx; ?>"><?php echo$keyx; ?></textarea>


</div>

</div>


<!-- 浮动标签、多行文本框 -->
<div class="mdui-textfield mdui-textfield-floating-label">
 
   
   
  
<script>
  document.getElementById('indeterminate-demo2').indeterminate = true;
</script>
      <br><button class="mdui-btn mdui-btn-raised" input type ="submit"  />点此确认修改</button>
</form>


</div>
    
<script>
  var tab = new mdui.Tab('#example4-tab');
  document.getElementById('example-4').addEventListener('open.mdui.dialog', function () {
    tab.handleUpdate();
  });
</script>
    


 
</body>

<!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
  
	<!--可无视-->
	<link rel="stylesheet" type="text/css" href="css/bootstrap-grid.min.css" /><!--CSS RESET-->

	
	<!--必要样式-->
	<link rel="stylesheet" href="css/naranja.min.css">
</head>
<body>
	
	<div class="container">
		<div class="row" style="padding:2em 0">
			<div class="col-md-2">
		
<div style="margin: 0 auto; width: 0%; position: fixed; bottom: 5px; height: 100％; font-size: 0; line-height: 0; z-index: 100; text-align: left;">

	
		</div></div>
	</div>


<script>
  var tab = new mdui.Tab('#example4-tab');
  document.getElementById('example-4').addEventListener('open.mdui.dialog', function () {
    tab.handleUpdate();
  });
</script>
	
	<script type="text/javascript" src="js/naranja.js"></script>
	<script type="text/javascript">
		function narn (type) {
		    naranja()[type]({
		      title: '你好',
		      text: '我们的小Jn控制面板正在内测',
		      timeout: 'keep',
		      buttons: [{
		        text: '知道了',
		        click: function (e) {
		          naranja().success({
		            title: '通知',
		            text: '知道了就好'
		          })
		        }
		      },{
		        text: '取消',
		        click: function (e) {
		          e.closeNotification()
		        }
		      }]
		    })
		  }
		  	function narn2 (type) {
		    naranja()[type]({
		      title: 'API使用教程',
		      text: '更改中文字段，挂上监控即可自动运行',
		      timeout: 'keep',
		      buttons: [{
		        text: '知道了',
		        click: function (e) {
		          naranja().success({
		            title: '来自小Jn的通知:',
		            text: '希望你学会了，改个文字对你来说应该问题不大!'
		          })
		        }
		      },{
		        text: '取消',
		        click: function (e) {
		          e.closeNotification()
		        }
		      }]
		    })
		  }
	</script>
</body>
</html>