<?php ob_start(); ?><div class="mdui-center" style="width: 200px"><!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <!-- MDUI CSS -->
    <link rel="stylesheet" href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"/>
    
  </head>
  <body>
   

    <!-- MDUI JavaScript -->
    <script src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"></script>
  </body>
</html>
<?php
error_reporting(0);
    

$key=$_COOKIE["ekey"];
$uid=$_COOKIE["uid"];
if ($_COOKIE["hulu"]==null) {
    setrawcookie("hulu",1,time()+259200);
}
setrawcookie("hulu",$_COOKIE["hulu"]+1,time()+259200);
echo"<br>已删帖子:".$h=$_COOKIE["hulu"]+1;
echo"目标帖子:".$z=$_GET["pid"];
$s=$_GET["s"];
if($_GET["pid"]>$_COOKIE["hulu"]+1){
    
    $cd=0.1*rand(10,15);
echo <<<EOF
<br><div class="mdui-spinner mdui-spinner-colorful"></div>
<br>状态:正在删帖子，系统返回:
<meta http-equiv="refresh" content="$cd">

EOF;
$pl=file_get_contents("http://floor.huluxia.com/post/create/list/ANDROID/4.1.8?platform=2&gkey=000000&app_version=4.2.0.7&versioncode=20141480&market_id=tool_tencent&_key=".$key."&phone_brand_type=UN&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&start=".$s."&count=20&user_id=".$uid);

$jsonStr = $pl;

$arr = json_decode($pl,true);

if($_GET["id"]==null){
$i=0;
}else{$i=$_GET["id"]-1;}
//超级获取术
$pid=$arr["posts"][$i]["postID"];//postID
$bt=$arr["posts"][$i]["title"];//标题
$jj=$arr["posts"][$i]["detail"];//简介
$name=$arr["posts"][$i]["user"]["nick"];//昵称
echo  $zc= file_get_contents("http://floor.huluxia.com/post/destroy/ANDROID/2.0?post_id=".$pid."&platform=2&gkey=000000&app_version=4.2.0.7&versioncode=329&market_id=tool_tencent&_key=".$key."&device_code=%5Bd%5Df6ec92f3-e2e4-43bc-a7f6-53677fe4d1a9&phone_brand_type=UN");
}
else
{
setrawcookie("hulu","0",time()+259200);ob_end_flush();
    echo <<<EOF
    状态:本次删帖完成
EOF;

}
?>