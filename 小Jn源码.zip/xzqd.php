<?php
`rm -rf qdxz/*`; 