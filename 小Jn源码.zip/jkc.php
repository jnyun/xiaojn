<?php
$wz=$_SERVER['HTTP_HOST'];
$a=file_get_contents("http://".$wz."/jkapi3.php");
  $myfile = fopen("jk3.txt", "w") or die("Unable to open file!");

fwrite($myfile,$a);
fclose($myfile);
//读取记录

$f=file("jk3.txt");

		echo$c=count($f);

for($i=0;$i<$c;$i++)
{
    echo $f[$i];

     file_get_contents($f[$i]);}
 