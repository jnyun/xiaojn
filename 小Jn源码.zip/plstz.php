<?php ob_start(); ?><!doctype html>
<html>
    <head>
        <!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    /><!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
  </body>
</html>
        <title>小Jn批量删帖</title>
        <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes"/>
    </head>
    <body>
        <form action="plstzapi.php" method="methget">
            
            <div class="mdui-textfield">
  <label class="mdui-textfield-label">数量(删除帖子数量):</label>
  <input class="mdui-textfield-input" type="number" name="pid">
</div><br>
<div class="mdui-textfield">
  <label class="mdui-textfield-label">从本页第几个帖子删起:</label>
  <input class="mdui-textfield-input" type="number" name="id">
  <div class="mdui-textfield-helper">适用于不能删除的帖子进行跳过</div>

</div>
<div class="mdui-textfield">
  <label class="mdui-textfield-label">start值:</label>
  <input class="mdui-textfield-input" type="number" name="s">
  <div class="mdui-textfield-helper">默认请填入0</div>
</div>

            <button class="mdui-btn mdui-btn-raised" type="submit">开始删帖</button>
        </form>
        <a href="/s.php">
<div class="mdui-chip">
  <span class="mdui-chip-icon"><i class="mdui-icon material-icons">videocam</i></span>
  <span class="mdui-chip-title">start值获取工具</span>
</div>
        <ul>
         
        </ul>
    </body>
</html><link rel="stylesheet" href="css/index.css" />


</ajn>
<?php
error_reporting(0);    
setrawcookie("hulu","0",time()+259200);ob_end_flush();
?>