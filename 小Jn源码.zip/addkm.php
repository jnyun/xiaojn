<?php

$filename='keyjn/'.$_GET["km"].'.txt';
     $ex=file_exists($filename);//检测文件存在与否
    if($_GET['km']==null)
	{
		echo '请填写完整';
	}
	else
	{

}

    if($ex==1)
{
    
$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $f2."\n");//写入内容
fwrite($myfile, "1");//写入
fclose($myfile);
echo"已存在";
}

else
{
if($ex==0)
{
    
$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, "1");//写入
fclose($myfile);
echo '创建成功';
}
}


?>