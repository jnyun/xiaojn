<!doctype html>
<html>
    <head>
        <!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    /><!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
  </body>
</html>
        <title>小Jn转移葫芦</title>
        <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes"/>
    </head>
    <body>
        <form action="huluapi.php" method="methget">
            
            <div class="mdui-textfield">
  <label class="mdui-textfield-label">pid(赠送帖子ID):</label>
  <input class="mdui-textfield-input" type="number" name="pid">
</div><br>
           <div class="mdui-textfield">
  <label class="mdui-textfield-label"> floor(赠送楼层):</label><input class="mdui-textfield-input" type="number" placeholder="可选参数" name="floor"><br>
             <div class="mdui-textfield">
  <label class="mdui-textfield-label"> 赠送葫芦数量:</label><input class="mdui-textfield-input" type="number" placeholder="" name="hulu"><br>
            <button class="mdui-btn mdui-btn-raised" type="submit">开始送葫芦</button>
        </form>
        <ul>
          <li>赠送楼层可以为空，赠送帖子ID必填</li>
          <li>开始送葫芦后请不要关闭浏览器（可以放在后台）</li>
          <li>赠送完后请关闭赠送页面</li>
        <li>不知道帖子ID?点击下方按钮!</li>
        </ul>
    </body>
</html><link rel="stylesheet" href="css/index.css" />
<a href="/tzidhq.php"><ajn>点此打开帖子ID获取工具</a></ajn>
<a href="/qchl.php"><ajn><br>点此清除已送葫芦记录</a>
</ajn>
<?php
setrawcookie("hulu","0",time()+2592000000000);
?>