<?php

$phoneNumber=$_COOKIE["phone"];
$password=$_COOKIE["key"];
$r=$_COOKIE["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);

$uid=$returnJson["user"]["userID"];


    

       $filename='jk3/'.$uid.'.txt';
      $ex=file_exists($filename);//检测文件存在与否
    
  
   


if($ex==1)
{
    
    if($_POST['name']==null)
	{
		echo '请填写完整';
	}
	else
	{
$myfilert2 = fopen($filename, "r") or die("Unable to open file!");
$f2 = fread($myfilert2,filesize($filename));
fclose($myfilert2);
$b=file($filename);
$c=count($b)/1;
}}
$filenamejn= "vip/".$uid.".txt"; 
 $f23=str_replace("\n","",file_get_contents($filenamejn));
 $zero1=strtotime (date("y-m-d")); //当前时间  ,注意H 是24小时 h是12小时 
$zero2=strtotime ($f23);  //到期时间，不能写2014-1-21 24:00:00  这样不对 
$guonian=ceil(($zero2-$zero1)/86400); //60s*60min*24h   
if($guonian>0){
echo $jn=100;   
}
else{
    $guonian=-$guonian;
    $jn=3; }
if ($c<$jn) {
if(strpos($_POST["name"],"http") !== false){
    
if(strpos($f2,$_POST["name"]) == false){
    if($ex==1)
{
    
$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $f2."\n");//写入旧内容
fwrite($myfile, $_POST['name']."&key=".$_POST['key']."&jkkey=".$_POST['jkkey']."&id=".$_POST['id']."&hz=".$_POST['hz']);//写入网址
fclose($myfile);
echo"新建监控成功";
}

else
{
if($ex==0)
{
    
$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $_POST['name']."&key=".$_POST['key']."&jkkey=".$_POST['jkkey']."&id=".$_POST['id']."&hz=".$_POST['hz']);//写入网址
fclose($myfile);
echo '监控创建成功';
}
}

}}else
{
    echo"格式错误，请填写带http的监控地址！";
    
}}else{echo"超出免费计划限制";}
?>