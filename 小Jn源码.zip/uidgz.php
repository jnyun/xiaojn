<?php
 $arr=file_get_contents("http://floor.huluxia.com/friendship/following/list/ANDROID/2.0?platform=2&gkey=000000&app_version=4.1.1.4.1&versioncode=325&market_id=tool_tencent&_key=".$_COOKIE["ekey"]."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&phone_brand_type=HW&start=0&count=20&user_id=".$_COOKIE["uid"]);
$arr2 = json_decode($arr,true);
for($i=0;$i<10;$i++){
echo"名字".$name=$arr2["friendships"]["user"][$i]["nick"];

    
}
?>