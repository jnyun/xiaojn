<?php 
error_reporting(0);
setcookie("hulu");
    Header("Location:/hulu.php")   ?>