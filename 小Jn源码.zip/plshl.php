状态:正在送葫芦，系统返回:
<meta http-equiv="refresh" content="10">
<?php
//屏蔽错误
ini_set("error_reporting","E_ALL & ~E_NOTICE");
//批量管理
$phoneNumber=$_COOKIE["phone"];
$password=$_COOKIE["key"];
$r=$_COOKIE["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];

switch($msg)
{
  case "账号或密码错误":
    echo '<script>window.alert("账号或密码错误！");</script>';
    break;
  case "参数不合法":
    echo '<script>window.alert("参数不合法！");</script>';
    break;
  case "账号不存在":
    echo '<script>window.alert("账号不存在");</script>';
    break;
  case "":
    
    

 $filename='xiaojnroobots/'.$uid.'.txt';
 $ex=file_exists($filename);//检测文件存在与否
if($ex==1)
{
$b=file($filename);
$c=count($b)/4;
$d=$c;

//关注
for($i=0;$i<$c;$i++)
{
$phone=$b[1+$i*4];
$n=substr($phone,0,strlen($phone)-1); 
$keyj=$b[4*$i+2];
$keyx = substr($keyj,0,strlen($keyj)-1); 
//关注代码
$phoneNumber=$n;
$password=md5($keyx);
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key2=$returnJson["_key"];


$a=file_get_contents("http://floor.huluxia.com/credits/transfer/ANDROID/2.0?platform=2&gkey=000000&app_version=4.1.1.4.1&versioncode=325&market_id=tool_tencent&_key=".$key2."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&phone_brand_type=HW&post_id=".$_GET["uid"]."&type_id=1&isadmin=0&score=".$_GET["hl"].'&score_txt=%E5%B0%8F%E7%8B%97%E6%9D%82%E7%89%9B%E9%80%BC%21');
$js=json_decode($a,true);
echo $zt=$js["msg"];
    $post=file_get_contents("http://floor.huluxia.com/post/detail/ANDROID/2.3?post_id=".$_GET["uid"]."&page_size=100");
    $post=json_decode($post,true);
   $my_cid=$post["comments"][count($post["comments"])-1]["commentID"];
    file_get_contents("http://floor.huluxia.com/comment/destroy/ANDROID/2.0?_key=".$key2."&comment_id=".$my_cid);

    echo"<br>赠送成功";

}}}