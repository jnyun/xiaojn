<?php ob_start(); ?><!doctype html>
<html>
    <head>
        <!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    /><!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
  </body>
</html>
        <title>小Jn自动一言</title>
        <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes"/>
    </head>
    <body>
        <form action="yyqd.php" method="methget">
            
            <div class="mdui-textfield">
  <label class="mdui-textfield-label">categoryID:</label>
  <input class="mdui-textfield-input" type="number" name="c">
</div><br>
<div class="mdui-textfield">
  <label class="mdui-textfield-label">tagid:</label>
  <input class="mdui-textfield-input" type="number" name="t">
  <div class="mdui-textfield-helper">分区ID</div>

</div>


            <button class="mdui-btn mdui-btn-raised" type="submit">开始自动一言</button>
        </form>
        <br>若均不填则默认给泳池一言

        <ul>
         
        </ul>
    </body>
</html><link rel="stylesheet" href="css/index.css" />


</ajn>
<?php
error_reporting(0);    
setrawcookie("hulu","0",time()+259200);ob_end_flush();
?>