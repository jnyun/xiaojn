<?php 
error_reporting(0);
$phoneNumber=$_COOKIE["phone"];
$password=$_COOKIE["key"];
$r=$_COOKIE["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);

echo$uid=$returnJson["user"]["userID"];

if ($uid!==null) {
    // code...

$file = "keyjn/".$_POST["km"].".txt"; 
if (!unlink($file))  
 {   echo ("卡密兑换失败，已失效的卡密:".$_POST["km"]);   } 
 else   {  
     echo ("卡密兑换成功，");   
     $filename='vip/'.$uid.'.txt';
     $ex=file_exists($filename);//检测文件存在与否
    if($ex==1)
{
 $f2=str_replace("\n","",file_get_contents($filename));
 
 
//判断卡密类型
if(strpos($_POST["km"],'月会员') !== false)
{
  
$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $a=date('Y-m-d', strtotime('+1 month', strtotime($f2))));//写入
fclose($myfile);
echo"会员续费成功，到期时间:".$a;

}}
if($ex==0)
{
    
$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $a=date("Y-m-d",strtotime("+10 day")));//写入
fclose($myfile);
echo '开通会员成功，首次开通附赠10天，到期时间'.$a;
}


   
 
 
//判断卡密类型
if(strpos($_POST["km"],'年会员') !== false)
{
  if($ex==1)
{
 $f2=str_replace("\n","",file_get_contents($filename));
$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $a=date('Y-m-d', strtotime('+1 year', strtotime($f2))));//写入
fclose($myfile);
echo"会员续费成功，到期时间:".$a;
}


if($ex==0)
{
    
$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $a=date("Y-m-d",strtotime("+3 month 1 year")));//写入
fclose($myfile);
echo '开通会员成功，首次开通附赠三个月，到期时间'.$a;
}


}}
}else {
    echo"系统异常，请升级APP!";
}
  ?>