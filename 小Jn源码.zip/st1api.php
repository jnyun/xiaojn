
<?php
$a='wz.txt';
$b=file($a);
$c=count($b);
$d=rand(0,$c);
$e=trim($b[$d],"\n");

$gs='wz.txt';
$f=file($gs);
$h=count($f);
$z=rand(0,$h);
$o=trim($f[$z],"\n");
$gs='bt.txt';
$f=file($gs);
$h=count($f);
$z=rand(0,$h);
$titlex=trim($f[$z],"\n");

//获取一言
$file = file("tz.txt");

//随机读取一行
$arr  = mt_rand( 0, count( $file ) - 1 );
echo$content  = trim($file[$arr],"\n");

//获取评论图片轮换
$file2 = file("tp.txt");
//随机读取一行
$arr2  = mt_rand( 0, count( $file2 ) - 1 );

echo$tp  = trim($file2[$arr2],"\n");

header("Content-type:text/html;charset=utf-8");
$t = $titlex;
$k = $_COOKIE["ekey"];
$w = "%0A".$e."[玫瑰]"."%0A".$o."%0A".$content.""
;$p =$tp;



$url = "http://floor.huluxia.com/post/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$k."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&cat_id=2&tag_id=-1&type=0&title=".$t."&detail=".$w."&patcha=&voice=&lng=0.0&lat=0.0&images=".$p;
   echo $html = file_get_contents($url);




?>