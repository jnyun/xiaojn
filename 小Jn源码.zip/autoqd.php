<title>小JnAPI</title><div class="mdui-ripple"><div style="height:500%;width:100%;background-color:#1fc8db;background-image:linear-gradient(141deg,#9fb8ad 0%,#1fc8db 51%,#2cb5e8 75%);color:white;opacity:0.95;text-align:center;margin:auto;color:#f3f3f3;font-size:50px;font-weight:550;">
<?php
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");//内容过期时间 强制浏览器去服务器去获取数据 而不是从缓存中读取数据
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");//标记内容最后修改时间
header("Cache-Control: no-store, no-cache, must-revalidate");//强制不缓存
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");//禁止本页被缓存
header("Access-Control-Allow-Origin: *"); // Support CORS

$phoneNumber=$_GET["phone"];
$password=md5($_GET["key"],false);
$r=$_GET["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];

switch($msg)
{
  case "账号或密码错误":
    echo '<script>window.alert("账号或密码错误！");</script>';
    break;
  case "参数不合法":
    echo '<script>window.alert("参数不合法！");</script>';
    break;
  case "账号不存在":
    echo '<script>window.alert("账号不存在");</script>';
    break;
  case "":
    
    
 
$account=$key;

if($account==null)
{
echo"登录过期或未登录！！！";
}

$getCatJson=file_get_contents("http://floor.huluxia.com/category/list/ANDROID/2.0");
$catArray=json_decode($getCatJson,true);
$cats=$catArray["categories"];

for($catOid=0;$catOid<count($cats);$catOid++)
{
$cid=$cats[$catOid]["categoryID"];



$result2=file_get_contents("http://floor.huluxia.com/user/signin/ANDROID/4.0?platform=2&gkey=000000&app_version=4.0.0.7&versioncode=20141436&market_id=floor_huluxia&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00-%5Bi%5D866934037372573-%5Bs%5D89861119147385482175&cat_id=".$cid);


$returnJson2=json_decode($result2,true);
$msg2=$returnJson2["msg"];
if($msg2==null)
{
echo"<br>签到成功，经验+5</br>";

}

sleep(0.1);

}




 break;
}

?>
</div>
</div>
