<!doctype html>
<html>
<head>
<title>回复 - 葫芦侠三楼</title>
<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes"/>
<style>
.comment-detail
{
width: 96%;
margin: 0 auto;
background-color: rgb(245, 245, 245);
border: none;
border: 1px solid #DaDaDa;
border-radius: 4px;
}

.user a
{
text-decoration: none;
color: rgb(14,188,224);
}

.user img
{
width: 10%;
border-radius: 50%;
}

hr
{
border: none;
border-bottom: 1px solid #DaDaDa;
height: 1px;
-webkit-transform: scaleY(0.5);
-webkit-transform-origin: 0 0;
}

.create-comment-detail
{
text-align: center;
}

.create-comment-detail textarea
{
border: none;
outline: none;
width: 100%;
height: 400px;
}

.create-comment-detail input
{
height: 40px;
width: 95%;
border: none;
border-radius: 5px;
background-color: #0099FF;
}

</style>
</head>


<!--判断是否登陆-->
<!--判断是否登陆-->
<?php
error_reporting(0);
if($_COOKIE["ekey"]==null)

  {
    Header("Location: /login.php");
  }


?>


<?php
$postJson=file_get_contents("http://floor.huluxia.com/post/detail/ANDROID/2.3?post_id=".$_GET["pid"]."&page_no=".$_GET["page"]."&page_size=20");
$postArray=json_decode($postJson,true);
?>




<body>


<?php
$text=$postArray["post"]["title"];
$uid=$postArray["post"]["user"]["userID"];
$nick=$postArray["post"]["user"]["nick"];
$avatar=$postArray["post"]["user"]["avatar"];
?>

<div class="user">

<?php

echo <<<EOF
<img src= $avatar referrerPolicy="no-referrer"/><span><a href="#" >$nick<a></span>
EOF;

?>

</div>
<br>

<div class="comment-detail">

<?php

echo mb_substr($text,0,40);

?>

</div>

<hr>


<div class="create-comment-detail">

<form action="createPostCommentRole.php" method="get">

<textarea cols="40" rows="40" name="detail" placeholder="填写内容，5~2000个字符"></textarea>
<input type="text" name="pid" value=<?php echo $_GET["pid"]; ?> style="display:none;"/>
<input type="submit" value="发布评论" />

</form>

</div>


<!--回复功能区-->

<!--见createPostCommentRole.php-->





</body>