<?php
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");//内容过期时间 强制浏览器去服务器去获取数据 而不是从缓存中读取数据
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");//标记内容最后修改时间
header("Cache-Control: no-store, no-cache, must-revalidate");//强制不缓存
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");//禁止本页被缓存
header("Access-Control-Allow-Origin: *"); // Support CORS

//需要参数phone，key
ini_set("display_errors","off");

    
 $filename='xiaojnroobots/'.$_COOKIE["uid"].'.txt';

$b=file($filename);
$c=count($b)/4;
$d=$c;
$i=$_GET["id"];

echo "<br>批量管理名字:".$name=trim($b[4*$i],"\n");

$str = $b[1+$i*4];;
 $phone=trim($str,"\n");
$key333=$b[4*$i+2];
 $keyj=trim($key333,"\n");
echo"功能:".$gn=$b[4*$i+3];

$curl = curl_init();

$ip_long = array(
       array('607649792', '608174079'), //36.56.0.0-36.63.255.255
       array('1038614528', '1039007743'), //61.232.0.0-61.237.255.255
       array('1783627776', '1784676351'), //106.80.0.0-106.95.255.255
       array('2035023872', '2035154943'), //121.76.0.0-121.77.255.255
       array('2078801920', '2079064063'), //123.232.0.0-123.235.255.255
       array('-1950089216', '-1948778497'), //139.196.0.0-139.215.255.255
       array('-1425539072', '-1425014785'), //171.8.0.0-171.15.255.255
       array('-1236271104', '-1235419137'), //182.80.0.0-182.92.255.255
       array('-770113536', '-768606209'), //210.25.0.0-210.47.255.255
       array('-569376768', '-564133889'), //222.16.0.0-222.95.255.255
   );
   $rand_key = mt_rand(0, 9);
   $ip= long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
$header = array("Connection: Keep-Alive","Accept: text/html, application/xhtml+xml, */*", "Pragma: no-cache", "Accept-Language: zh-Hans-CN,zh-Hans;q=0.8,en-US;q=0.5,en;q=0.3","User-Agent: okhttp/3.8.1");

	curl_setopt($curl,CURLOPT_URL,'http://floor.huluxia.com/account/login/ANDROID/4.0?platform=2&gkey=000000&app_version=4.1.1.6.2&versioncode=335&market_id=tool_tencent&_key=&phone_brand_type=UN&device_code=[d]16485814-230d-424c-8af1-fda8f42d1e25&password='.md5($keyj).'&login_type=2&account='.$phone."%0A");
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($curl,CURLOPT_CONNECTTIMEOUT,10);
	curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
	curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
	//curl_setopt($curl,CURLOPT_HTTPHEADER,['X-FORWARDED-FOR:164.89.81.12','CLIENT-IP:164.89.81.12']);
	curl_setopt($curl,CURLOPT_REFERER,'');
	curl_setopt($curl,CURLOPT_USERAGENT,'okhttp/3.8.1');
	$post= curl_exec($curl);
	curl_close($curl);
	$arr = json_decode($post, true);
// Access values from the associative array

 $jnsb=$arr["_key"];
 if($jnsb!=null){
 //{echo'{"key":'.$arr["_key"].', "uid":'.$arr["user"]["userID"].'}';
 echo"good";
  $userMsg=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/2.1?_key=".$jnsb."&user_id=".$arr["user"]["userID"]);
$user=json_decode($userMsg,true);
$name=$user["nick"];
$returnJson=json_decode($post,true);
echo $msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];


 
 
 }

 
  //随机数 
  
function get_password( $length = 2 ) 
{
    $str = substr(md5(time()), 0, $length);//md5加密，time()当前时间戳
    return $str=$sjs;
}
  
   
//name
$name2=substr($name,0,strlen($name)-1);

//评论获取
$pl2=file_get_contents("http://floor.huluxia.com/message/new/list/ANDROID/4.0?platform=2&gkey=000000&app_version=4.0.1.9.1&versioncode=309&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&type_id=2&start=0&count=2");
$arr2 = json_decode($pl2,true);
//超级获取术
echo"<p>他人评论内容：".$a=$arr2["datas"][0]["content"]["text"]."</p>";//评论内容
echo"<p>评论ID:".$plid=$arr2["datas"][0]["content"]["commentID"]."</p>";//评论ID
echo"<p>该评论人ID:".$user=$arr2["datas"][0]["content"]["user"]["userID"]."</p>";//用户ID
$tx=$arr2["datas"][0]["content"]["user"]["avatar"];//头像
echo"<p>该评论人昵称:".$name=$arr2["datas"][0]["content"]["user"]["nick"]."</p>";//昵称



$ys=$arr2["datas"][0]["content"]["seq"];//楼层
$plid=$arr2["datas"][0]["content"]["commentID"];//评论ID


//读取记录
$myfilert2 = fopen("1.txt", "r") or die("Unable to open file!");
$f2 = fread($myfilert2,filesize("1.txt"));
fclose($myfilert2);


if(eregi($plid,$f2))
{echo"已回复，空参数防止多次回复";}else{
$plid=$arr2["datas"][0]["content"]["commentID"];//评论ID
   //记录

    $myfile2 = fopen("1.txt", "w") or die("Unable to open file!");
$txt2 = $f2.$plid."\n";
fwrite($myfile2, $txt2);
fclose($myfile2);


//tzid获取
$get = "http://floor.huluxia.com/message/new/list/ANDROID/4.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&type_id=2&start=0&count=1";
   $pl = file_get_contents($get);
    $pl_begin = mb_strpos($pl,',"title":"') + mb_strlen(',"title":"');//提取的开始位置
$pl_end = mb_strpos($pl,'","ext":null,"detail":null,"') - $pl_begin;//提取的结束位置
$plw = mb_substr($pl,$pl_begin,$pl_end);
$h = $plw;
$id = file_get_contents($get);
    $id_begin = mb_strpos($id,'{"postID":') + mb_strlen('{"postID":');//提取的开始位置
$id_end = mb_strpos($id,',"title":"'.$h) - $id_begin;//提取的结束位置
$tzid = mb_substr($id,$id_begin,$id_end);
if(eregi(6,$gn)){echo"我要点赞功能开启";
if(strpos($a,'我要点赞') !== false)
{
//执行点赞
$key=$returnJson23["_key"];
$user=$arr2["datas"][0]["content"]["user"]["userID"];
    $gzdf = "http://floor.huluxia.com/post/praise/ANDROID/2.1?platform=2&gkey=000000&app_version=4.1.1.2.2&versioncode=318&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=
".$tzid;
   echo "返回信息".$gzgzgz4 = file_get_contents($gzdf);
   
$url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=点赞了，有葫芦吗?[滑稽}".$sjs;
     $zt = file_get_contents($url3);
     $jsonStr = $zt;

$arr2 = json_decode($zt,true);
     echo"<p>处理状态：" .$plw=$arr2["msg"]."</p>"; 
}}
 

 if(eregi(5,$gn)){echo"我要互关功能开启";
if(strpos($a,'我要互关') !== false|strpos($a,'我要关注') !== false)
{
    $key=$returnJson23["_key"];
$user=$arr2["datas"][0]["content"]["user"]["userID"];
    //判断关系
     $gx=file_get_contents("http://floor.huluxia.com/friendship/following/list/ANDROID/2.0?platform=2&gkey=000000&app_version=4.1.1.2.2&versioncode=318&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&start=0&count=100&user_id=".$user."");
    $gx2 = json_decode($gx,true);
    echo$gx3=$gx[user][userID];
    if(eregi($uid,$gx)){
//执行关注
 $key=$returnJson23["_key"];
$user=$arr2["datas"][0]["content"]["user"]["userID"];
    $gzdf = "http://floor.huluxia.com/friendship/follow/ANDROID/2.0?user_id=".$user."&platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e";
   echo "关注返回信息".$gzgzgz = file_get_contents($gzdf);
   
$url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=关注你了，不要取关哦!".$sjs;
     $zt = file_get_contents($url3);
     $jsonStr = $zt;

$arr2 = json_decode($zt,true);
     echo"<p>处理状态：" .$plw=$arr2["msg"]."</p>"; 
}
    else
    {$url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=大佬，请先关注我!!![滑稽]".$sjs;
     $zt = file_get_contents($url3);
     $jsonStr = $zt;

$arr2 = json_decode($zt,true);
     echo"<p>处理状态：" .$plw=$arr2["msg"]."</p>"; }
}}




   if(eregi(2,$gn)){echo"我要关注功能开启";
if(strpos($a,'我要关注') !== false)
{
//执行关注
$key=$returnJson23["_key"];
$user=$arr2["datas"][0]["content"]["user"]["userID"];
    $gzdf = "http://floor.huluxia.com/friendship/follow/ANDROID/2.0?user_id=".$user."&platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e";
   echo "关注返回信息".$gzgzgz = file_get_contents($gzdf);
   
$url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=关注你了！互关吗？".$sjs;
     $zt = file_get_contents($url3);
     $jsonStr = $zt;

$arr2 = json_decode($zt,true);
     echo"<p>处理状态：" .$plw=$arr2["msg"]."</p>"; 
}
 


   if(eregi(3,$gn)){echo"我要取关功能开启";
   $key=$returnJson23["_key"];
$user=$arr2["datas"][0]["content"]["user"]["userID"];
if(strpos($a,'不要') !== false)
{
//执行取关

    $qxgz = "http://floor.huluxia.com/friendship/unfollow/ANDROID/2.0?user_id=".$user."&platform=2&gkey=000000&app_version=4.1.1.1.2&versioncode=313&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e";
   echo "关注返回信息".$qx = file_get_contents($qxgz);
   
$urlqxgz = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=好的，取关了[滑稽][弱]".$sjs;
     $qx = file_get_contents($urlqxgz);
     $jsonStr = $qxgzhh;

$arrqx = json_decode($qx,true);
     echo";处理状态：" .$plwqx=$arrqx["msg"]; 
}
//记录

    $myfile2 = fopen("1.txt", "w") or die("Unable to open file!");
$txt2 = $f2.$plid."\n";
fwrite($myfile2, $txt2);
fclose($myfile2);
}
   if(eregi(3,$gn)){echo"";
if(strpos($a,'取关') !== false)
{
//执行取关

    $qxgz = "http://floor.huluxia.com/friendship/unfollow/ANDROID/2.0?user_id=".$user."&platform=2&gkey=000000&app_version=4.1.1.1.2&versioncode=313&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e";
   echo "关注返回信息".$qx = file_get_contents($qxgz);
   
$urlqxgz = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=好的，取关了[滑稽][弱]".$sjs;
     $qx = file_get_contents($urlqxgz);
     $jsonStr = $qxgzhh;

$arrqx = json_decode($qx,true);
     echo";处理状态：" .$plwqx=$arrqx["msg"]; 
}
//记录

    $myfile2 = fopen("1.txt", "w") or die("Unable to open file!");
$txt2 = $f2.$plid."\n";
fwrite($myfile2, $txt2);
fclose($myfile2);
}
   if(eregi(3,$gn)){
if(strpos($a,'不互关') !== false)
{
//执行取关

    $qxgz = "http://floor.huluxia.com/friendship/unfollow/ANDROID/2.0?user_id=".$user."&platform=2&gkey=000000&app_version=4.1.1.1.2&versioncode=313&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e";
   echo "关注返回信息".$qx = file_get_contents($qxgz);
   
$urlqxgz = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=好的，取关了[滑稽][弱][滑稽][弱]".$sjs;
     $qx = file_get_contents($urlqxgz);
     $jsonStr = $qxgzhh;

$arrqx = json_decode($qx,true);
     echo";处理状态：" .$plwqx=$arrqx["msg"]; 
}
//记录

    $myfile2 = fopen("1.txt", "w") or die("Unable to open file!");
$txt2 = $f2.$plid."\n";
fwrite($myfile2, $txt2);
fclose($myfile2);
}





   if(eregi(4,$gn)){echo"要广告费功能开启";
if(strpos($a,'广告') !== false)
{
//执行取关

    $qxgz = "http://floor.huluxia.com/friendship/unfollow/ANDROID/2.0?user_id=".$user."&platform=2&gkey=000000&app_version=4.1.1.1.2&versioncode=313&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e";
   echo "关注返回信息".$qx = file_get_contents($qxgz);
   
$urlqxgz = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=广告费拿来[滑稽][弱]".$sjs;
     $qx = file_get_contents($urlqxgz);
     $jsonStr = $qxgzhh;

$arrqx = json_decode($qx,true);
     echo";处理状态：" .$plwqx=$arrqx["msg"]; 
     
}
}
if(eregi(1,$gn)){echo"聊天功能开启";
   //回复
   $plid=$arr2["datas"][0]["content"]["commentID"];//评论ID
   //处理评论
$url2 = "http://". $_SERVER['HTTP_HOST']."/jnjqrapi.php?name=".$name2."&q=".$a;
   echo";批量管理回复内容：" .$html = file_get_contents($url2)."[滑稽][玫瑰]".$sjs;
  }
  //API异常
    if($html=="[滑稽][玫瑰]")
   {$html=$name2."召唤成功![滑稽][玫瑰]".$sjs;}  
$url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=".$html;
     $zt = file_get_contents($url3);
     $jsonStr = $zt;
$arr2 = json_decode($zt,true);
     echo";处理状态：" .$plw=$arr2["msg"]; }
}



if ($_GET["qd"]!=null) {
    // code...
echo"<br>签到开启:";
if ($_COOKIE["qd"]==null) {
$getCatJson=file_get_contents("http://floor.huluxia.com/category/list/ANDROID/2.0");
$catArray=json_decode($getCatJson,true);
$cats=$catArray["categories"];

for($catOid=0;$catOid<count($cats);$catOid++)
{
$cid=$cats[$catOid]["categoryID"];



$result2=file_get_contents("http://floor.huluxia.com/user/signin/ANDROID/4.0?platform=2&gkey=000000&app_version=4.0.0.7&versioncode=20141436&market_id=floor_huluxia&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00-%5Bi%5D866934037372573-%5Bs%5D89861119147385482175&cat_id=".$cid);


$returnJson2=json_decode($result2,true);
$msg2=$returnJson2["msg"];

sleep(0.1);

}
echo"签到成功";
setrawcookie(qd,1,time()+60*1000*60*9);
    
}
else{echo"已签到，已过滤防止重复签到";}

}


if ($_GET["qt"]!=null) {
    echo"<br>乞讨开启";
$url32="http://djbjd.top/qthljn.php?phone=".$phone.'&key='.$keyj;
$post3=file_get_contents($url32);
}


if ($_GET["yy"]!=null) {
    echo"<br>一言开启";
$url323="http://djbjd.top/yyjk.php?phone=".$phone.'&key='.$keyj;
$post3=file_get_contents($url323);
  }
?>