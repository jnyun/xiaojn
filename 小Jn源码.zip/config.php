<?php
$host = "localhost";
//MYSQL主机
$user = "jk";
//MYSQL用户
$pwd ="dali2005";
//用户密码
$dbname = "jk";
//数据库名
?>