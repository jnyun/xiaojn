<?php 
error_reporting(0);
setrawcookie("gxzb","1",time()+3600*5200);
    Header("Location:/tool.php")   ?>