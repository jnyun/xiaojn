<?php
`rm -rf stxz/*`; 