<html lang="zh-cmn-Hans">
  <head>
      <meta http-equiv="refresh" content="3">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
<!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    />
<!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
    
    
    <div class="mdui-progress">
  <div class="mdui-progress-indeterminate"></div>
</div>
    
    <div class="mdui-card">

  <!-- 卡片头部，包含头像、标题、副标题 -->
  <div class="mdui-card-header">
    <img class="mdui-card-header-avatar" src="static/picture/hill.jpg"/>
    <div class="mdui-card-header-title">小Jn批量管理前端框架</div>
    <div class="mdui-card-header-subtitle">运行中</div>
  </div>

  <!-- 卡片的媒体内容，可以包含图片、视频等媒体内容，以及标题、副标题 -->
  <div class="mdui-card-media">
    <img src="static/picture/hill.jpg"/>

    <!-- 卡片中可以包含一个或多个菜单按钮 -->
    

  <!-- 卡片的标题和副标题 -->
  <div class="mdui-card-primary">
    <div class="mdui-card-primary-title">欢迎使用小Jn葫芦侠批量管理</div>
    <div class="mdui-card-primary-subtitle">详细信息</div>
  </div>

  <!-- 卡片的内容 -->
  <div class="mdui-card-content"></div>

  <!-- 卡片的按钮 -->
  <div class="mdui-card-actions">
    <button class="mdui-btn mdui-ripple">运行中</button>
    <button class="mdui-btn mdui-ripple">运行频率3秒/次</button>
 </div>

</div>

    <div class="mdui-panel-item mdui-panel-item-open">
    <div class="mdui-panel-item-header">运行日志</div>
    <div class="mdui-panel-item-body">
   
  <?php


//需要参数phone，key
ini_set("display_errors","off");

     $filename2='jkkey/'.$_GET["u"].'.txt';

$b2=file_get_contents($filename2);


 $filename='xiaojnroobots/'.$_GET["u"].'.txt';

$b=file($filename);
$c=count($b)/4;
$d=$c;
$i=$_GET["id"];

echo "<br>批量管理名字:".$name=$b[4*$i];

$str = $b[1+$i*4];;
 $phone=trim($str,"\n");
$key333=$b[4*$i+2];
 $keyj=trim($key333,"\n");
echo"功能:".$gn=$b[4*$i+3];

//登录
$phoneNumber2=$phone;
$password2=md5($keyj,false);
//登录模块
$curl = curl_init();

$ip_long = array(
       array('607649792', '608174079'), //36.56.0.0-36.63.255.255
       array('1038614528', '1039007743'), //61.232.0.0-61.237.255.255
       array('1783627776', '1784676351'), //106.80.0.0-106.95.255.255
       array('2035023872', '2035154943'), //121.76.0.0-121.77.255.255
       array('2078801920', '2079064063'), //123.232.0.0-123.235.255.255
       array('-1950089216', '-1948778497'), //139.196.0.0-139.215.255.255
       array('-1425539072', '-1425014785'), //171.8.0.0-171.15.255.255
       array('-1236271104', '-1235419137'), //182.80.0.0-182.92.255.255
       array('-770113536', '-768606209'), //210.25.0.0-210.47.255.255
       array('-569376768', '-564133889'), //222.16.0.0-222.95.255.255
   );
   $rand_key = mt_rand(0, 9);
   $ip= long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
$header = array("Connection: Keep-Alive","Accept: text/html, application/xhtml+xml, */*", "Pragma: no-cache", "Accept-Language: zh-Hans-CN,zh-Hans;q=0.8,en-US;q=0.5,en;q=0.3","User-Agent: okhttp/3.8.1");

	curl_setopt($curl,CURLOPT_URL,'http://floor.huluxia.com/account/login/ANDROID/4.0?platform=2&gkey=000000&app_version=4.1.1.6.2&versioncode=335&market_id=tool_tencent&_key=&phone_brand_type=UN&device_code=[d]16485814-230d-424c-8af1-fda8f42d1e25&password='.$password2.'&login_type=2&account='.$phoneNumber2."%0A");
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($curl,CURLOPT_CONNECTTIMEOUT,10);
	curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
	curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
	//curl_setopt($curl,CURLOPT_HTTPHEADER,['X-FORWARDED-FOR:164.89.81.12','CLIENT-IP:164.89.81.12']);
	curl_setopt($curl,CURLOPT_REFERER,'');
	curl_setopt($curl,CURLOPT_USERAGENT,'okhttp/3.8.1');
	$post= curl_exec($curl);
	curl_close($curl);
	$arr = json_decode($post, true);
// Access values from the associative array

 $jnsb=$arr["_key"];
 if($jnsb!=null){
 //{echo'{"key":'.$arr["_key"].', "uid":'.$arr["user"]["userID"].'}';
 echo"good";
  $userMsg=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/2.1?_key=".$jnsb."&user_id=".$arr["user"]["userID"]);
$user=json_decode($userMsg,true);
$name=$user["nick"];
$returnJson=json_decode($post,true);
echo $msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];


 
 
 }



 
  
//name
$name2=$name;

//评论获取
$pl2=file_get_contents("http://floor.huluxia.com/message/new/list/ANDROID/4.0?platform=2&gkey=000000&app_version=4.0.1.9.1&versioncode=309&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&type_id=2&start=0&count=2");
$arr2 = json_decode($pl2,true);
//超级获取术
echo"<p>他人评论内容：".$a=$arr2["datas"][0]["content"]["text"]."</p>";//评论内容
echo"<p>评论ID:".$plid=$arr2["datas"][0]["content"]["commentID"]."</p>";//评论ID
echo"<p>该评论人ID:".$user=$arr2["datas"][0]["content"]["user"]["userID"];//用户ID
$tx=$arr2["datas"][0]["content"]["user"]["avatar"];//头像
echo"<p>该评论人昵称:".$name=$arr2["datas"][0]["content"]["user"]["nick"]."</p>";//昵称



$ys=$arr2["datas"][0]["content"]["seq"];//楼层
$plid=$arr2["datas"][0]["content"]["commentID"];//评论ID


//读取记录
$myfilert2 = fopen("1.txt", "r") or die("Unable to open file!");
$f2 = fread($myfilert2,filesize("1.txt"));
fclose($myfilert2);

$plid=$arr2["datas"][0]["content"]["commentID"];//评论ID
if(eregi($plid,$f2))
{echo"已回复，空参数防止多次回复";}else{

   //记录

    $myfile2 = fopen("1.txt", "w") or die("Unable to open file!");
$txt2 = $f2.$plid."\n";
fwrite($myfile2, $txt2);
fclose($myfile2);


//tzid获取
$get = "http://floor.huluxia.com/message/new/list/ANDROID/4.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&type_id=2&start=0&count=1";
   $pl = file_get_contents($get);
    $pl_begin = mb_strpos($pl,',"title":"') + mb_strlen(',"title":"');//提取的开始位置
$pl_end = mb_strpos($pl,'","ext":null,"detail":null,"') - $pl_begin;//提取的结束位置
$plw = mb_substr($pl,$pl_begin,$pl_end);
$h = $plw;
$id = file_get_contents($get);
    $id_begin = mb_strpos($id,'{"postID":') + mb_strlen('{"postID":');//提取的开始位置
$id_end = mb_strpos($id,',"title":"'.$h) - $id_begin;//提取的结束位置
$tzid = mb_substr($id,$id_begin,$id_end);

$plid=$arr2["datas"][0]["content"]["commentID"];//评论ID
if(eregi($plid,$f2))
{echo"已回复，空参数防止多次回复";}else{


if(eregi(8,$gn)){echo"签到功能开启";
if(strpos($a,'签到') !== false)
{
    $filename='qdxz/'.$uid.'.txt';
      $ex=file_exists($filename);//检测文件存在与否
    
if($ex!=1)
{
$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, "开始");//写入次数

fclose($myfile);
echo '<br>签到器创建成功';
$url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=您是第一个使用者，请再发一次签到".$content."&patcha=&images=".$tp;
    echo $zt = file_get_contents($url3);
    
	}
	else
	{
	    


   if (eregi($user,$f2)) {
       echo"签到过了";
    $url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=你签到过啦。。。".$content."&patcha=&images=".$tp;
    echo $zt = file_get_contents($url3);
   }
   else{
       
       //操作送葫芦给签到者
      echo $zt=file_get_contents("http://floor.huluxia.com/credits/transfer/ANDROID/2.0?_key=".$key."&post_id=".$plid."&type_id=2&isadmin=0&score=1&score_txt=签到送葫芦！");
       $jn='{"msg":"","iscredits":1,"status":1}';
   if($zt==$jn){
   //签到成功
       $myfilert2 = fopen($filename, "r") or die("Unable to open file!");
echo$f2 = fread($myfilert2,filesize($filename));
fclose($myfilert2);
$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $f2."\n".$user);//写入UID

fclose($myfile);
echo '<br>签到记录';
   }else{
       //签到失败
        $url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=今天葫芦上限或者是我没葫芦啦，请明天再来试试。。。".$content."&patcha=&images=".$tp;
    echo $zt = file_get_contents($url3);
       
   }

    
    } 
    
}}}



if(eregi(7,$gn)){echo"涩图功能开启";
if(strpos($a,'涩图') != false)
{
    
   
   //获取评论拟人
$file = file("pl.txt");
//随机读取一行
$arr  = mt_rand( 0, count( $file ) - 1 );
echo"<br>回复内容:";
echo$content  = trim($file[$arr],"\n");
 //获取评论图片轮换
$file2 = file("st.txt");
//随机读取一行
$arr2  = mt_rand( 0, count( $file2 ) - 1 );

echo$tp  = trim($file2[$arr2],"\n");

$url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=给你涩图，给我个葫芦?".$content."&patcha=&images=".$tp;
    echo $zt = file_get_contents($url3);
    file_put_contents("pid.txt",$pid);
  }}
    
     
    

   if(eregi(6,$gn)){echo"我要点赞功能开启";
if(strpos($a,'我要点赞') !== false)
{
//执行点赞
$key=$returnJson23["_key"];
$user=$arr2["datas"][0]["content"]["user"]["userID"];
    $gzdf = "http://floor.huluxia.com/post/praise/ANDROID/2.1?platform=2&gkey=000000&app_version=4.1.1.2.2&versioncode=318&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=
".$tzid;
   echo "返回信息".$gzgzgz4 = file_get_contents($gzdf);
   
$url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=点赞了，有葫芦吗?[滑稽]".$sjs;
     $zt = file_get_contents($url3);
     $jsonStr = $zt;

$arr2 = json_decode($zt,true);
     echo"<p>处理状态：" .$plw=$arr2["msg"]."</p>"; 
}}
 

 if(eregi(5,$gn)){echo"我要互关功能开启";
if(strpos($a,'互关') !== false|strpos($a,'关注') !== false)
{
    $key=$returnJson23["_key"];
$user=$arr2["datas"][0]["content"]["user"]["userID"];
    //判断关系
     $gx=file_get_contents("http://floor.huluxia.com/friendship/following/list/ANDROID/2.0?platform=2&gkey=000000&app_version=4.1.1.2.2&versioncode=318&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&start=0&count=100&user_id=".$user."");
    $gx2 = json_decode($gx,true);
    echo$gx3=$gx[user][userID];
    if(eregi($uid,$gx)){
//执行关注
 $key=$returnJson23["_key"];
$user=$arr2["datas"][0]["content"]["user"]["userID"];
    $gzdf = "http://floor.huluxia.com/friendship/follow/ANDROID/2.0?user_id=".$user."&platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e";
   echo "关注返回信息".$gzgzgz = file_get_contents($gzdf);
   
$url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=关注你了，别取消哦!".$sjs;
     $zt = file_get_contents($url3);
     $jsonStr = $zt;

$arr2 = json_decode($zt,true);
     echo"<p>处理状态：" .$plw=$arr2["msg"]."</p>"; 
}
    else
    {$url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=大佬，请先关注我!!![滑稽]".$sjs;
     $zt = file_get_contents($url3);
     $jsonStr = $zt;
//执行取关

    $qxgz = "http://floor.huluxia.com/friendship/unfollow/ANDROID/2.0?user_id=".$user."&platform=2&gkey=000000&app_version=4.1.1.1.2&versioncode=313&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e";
   echo "关注返回信息".$qx = file_get_contents($qxgz);
   
$arr2 = json_decode($zt,true);
     echo"<p>处理状态：" .$plw=$arr2["msg"]."</p>"; }
}}
}
if(eregi(4,$gn)){echo"要广告费功能开启";
if(strpos($a,'广告') != false)
{

$urlqxgz = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=广告费拿来[滑稽][弱]";
     $qx = file_get_contents($urlqxgz);
     $jsonStr = $qx;

$arrqx = json_decode($qx,true);
     echo";处理状态：" .$plwqx=$arrqx["msg"]; 
     
}
}

if(eregi(3,$gn)){echo"我要取关功能开启";
   $key=$returnJson23["_key"];
$user=$arr2["datas"][0]["content"]["user"]["userID"];
if(strpos($a,'不要')|strpos($a,'取关')|strpos($a,'不互关') !== false|strpos($a,'下次一定') !== false)
{
//执行取关

    $qxgz = "http://floor.huluxia.com/friendship/unfollow/ANDROID/2.0?user_id=".$user."&platform=2&gkey=000000&app_version=4.1.1.1.2&versioncode=313&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e";
   echo "关注返回信息".$qx = file_get_contents($qxgz);
   
$urlqxgz = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=好的，取关了[滑稽][弱]".$sjs;
     $qx = file_get_contents($urlqxgz);
     $jsonStr = $qxgzhh;

$arrqx = json_decode($qx,true);
     echo";处理状态：" .$plwqx=$arrqx["msg"]; 
}

}
  
  
  if(strpos($a,'举报') !== false)
{

$url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=大佬，这边我们没有违规！小Jn葫芦侠批量管理是一个严格符合葫芦侠规定的批量管理，搭配极智AI，每个评论都与帖子有关，并没有恶意水回复，如果你实在无法忍受，请将我的评论删除，谢谢合作！
做人不容易做小Jn也不容易，希望互相理解，谢谢！
".$sjs;
     $zt = file_get_contents($url3);
     $jsonStr = $zt;

$arr2 = json_decode($zt,true);
     echo"<p>处理状态：" .$plw=$arr2["msg"]."</p>"; 
}


   if(eregi(2,$gn)){echo"我要关注功能开启";
if(strpos($a,'我要关注') !== false|strpos($a,'关注') !== false)
{
//执行关注
$key=$returnJson23["_key"];
$user=$arr2["datas"][0]["content"]["user"]["userID"];
    $gzdf = "http://floor.huluxia.com/friendship/follow/ANDROID/2.0?user_id=".$user."&platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e";
   echo "关注返回信息".$gzgzgz = file_get_contents($gzdf);
   
$url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=关注你了！互关吗？".$sjs;
     $zt = file_get_contents($url3);
     $jsonStr = $zt;

$arr2 = json_decode($zt,true);
     echo"<p>处理状态：" .$plw=$arr2["msg"]."</p>"; 
     
}
// if(eregi(1,$gn)){echo"聊天功能开启";
   //回复
 //  $plid=$arr2["datas"][0]["content"]["commentID"];//评论ID
   //处理评论
//$url2 = "http://". $_SERVER['HTTP_HOST']."/jnjqrapi.php?name=".$name2."&q=".$a;
  // echo";批量管理回复内容：" .$html = file_get_contents($url2).$_GET["hj"].$sjs;
  }
  //API异常
 //   if($html==$_GET["hj"])
//   {$html=$name2."召唤成功![滑稽][玫瑰]".$sjs;}  
//$url3b = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=".$html;
 //   echo $zt = file_get_contents($url3b);
   //  $jsonStr = $zt;
//$arr2 = json_decode($zt,true);
    // echo";处理状态：" .$plw=$arr2["msg"]; }


  
}
if(eregi(1,$gn)){echo"聊天功能不能开启";
   //回复
   $plid=$arr2["datas"][0]["content"]["commentID"];//评论ID
   //处理评论
//$url2 = "http://". $_SERVER['HTTP_HOST']."/jnjqrapi.php?name=".$name2."&q=".$a;
 //  echo";批量管理回复内容：" .$html = file_get_contents($url2)."[滑稽][玫瑰]".$sjs;
 }
  //API异常
 //   if($html=="[滑稽][玫瑰]")
//   {$html=$name2."召唤成功![滑稽][玫瑰]".$sjs;}  
//$url3b = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=".$html;
  //  echo $zt = file_get_contents($url3b);
  //   $jsonStr = $zt;
//$arr2 = json_decode($zt,true);
 //    echo";处理状态：" .$plw=$arr2["msg"];
    



?>
   
   
   
   
   
      </div>
  </div>