<?php

$q=file_get_contents("http://floor.huluxia.com/friendship/follow/ANDROID/2.0?user_id=".$_GET["uid"]."&platform=2&gkey=000000&app_version=4.1.1.2.2&versioncode=318&market_id=tool_tencent&_key=".$_COOKIE["ekey"]."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e");
$b='{"msg":"","status":1}';
if($q==$b){
    echo"关注成功";
}
else{
    echo"关注失败，可能是关注速度过快，请稍候再试";
}