<?php ob_start(); ?>
<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <!-- MDUI CSS -->
    <link rel="stylesheet" href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"/>
    
  </head>
  <body>
   

    <!-- MDUI JavaScript -->
    <script src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"></script>
  </body>
</html>
<div class="mdui-spinner mdui-spinner-colorful"></div>
<?php
//屏蔽错误
ini_set("error_reporting","E_ALL & ~E_NOTICE");
//批量管理验证
$getCatJson=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/4.1.8?platform=2&gkey=000000&app_version=4.2.0.4.2&versioncode=20141472&market_id=floor_web&_key=".$_COOKIE["ekey"]."&device_code=%5Bd%5D16485814-230d-424c-8af1-fda8f42d1e25&phone_brand_type=UN&user_id=".$_COOKIE["uid"]);
$catArray=json_decode($getCatJson,true);
$cats=$catArray["msg"];
if($cats==null){

$uid=$_COOKIE["uid"];
    
    

 $filename='xiaojnroobots/'.$uid.'.txt';
 $ex=file_exists($filename);//检测文件存在与否
if($ex==1)
{
$b=file($filename);
$c=count($b)/4;
$d=$c;

//顶帖
$i=$_GET["id"];
if ($i==null) {
    $i=0;
}
//获取数据
$phone=$b[1+$i*4];
$n=substr($phone,0,strlen($phone)-1); 
$keyj=$b[4*$i+2];
$keyx = substr($keyj,0,strlen($keyj)-2); 
$m=md5($keyx);
//登录
$curl = curl_init();

$ip_long = array(
       array('607649792', '608174079'), //36.56.0.0-36.63.255.255
       array('1038614528', '1039007743'), //61.232.0.0-61.237.255.255
       array('1783627776', '1784676351'), //106.80.0.0-106.95.255.255
       array('2035023872', '2035154943'), //121.76.0.0-121.77.255.255
       array('2078801920', '2079064063'), //123.232.0.0-123.235.255.255
       array('-1950089216', '-1948778497'), //139.196.0.0-139.215.255.255
       array('-1425539072', '-1425014785'), //171.8.0.0-171.15.255.255
       array('-1236271104', '-1235419137'), //182.80.0.0-182.92.255.255
       array('-770113536', '-768606209'), //210.25.0.0-210.47.255.255
       array('-569376768', '-564133889'), //222.16.0.0-222.95.255.255
   );
   $rand_key = mt_rand(0, 9);
   $ip= long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
$header = array("Connection: Keep-Alive","Accept: text/html, application/xhtml+xml, */*", "Pragma: no-cache", "Accept-Language: zh-Hans-CN,zh-Hans;q=0.8,en-US;q=0.5,en;q=0.3","User-Agent: okhttp/3.8.1");

	curl_setopt($curl,CURLOPT_URL,'http://floor.huluxia.com/account/login/ANDROID/4.0?platform=2&gkey=000000&app_version=4.1.1.6.2&versioncode=335&market_id=tool_tencent&_key=&phone_brand_type=UN&device_code=[d]16485814-230d-424c-8af1-fda8f42d1e25&password='.$m.'&login_type=2&account='.$n."%0A");
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($curl,CURLOPT_CONNECTTIMEOUT,10);
	curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
	curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
	//curl_setopt($curl,CURLOPT_HTTPHEADER,['X-FORWARDED-FOR:164.89.81.12','CLIENT-IP:164.89.81.12']);
	curl_setopt($curl,CURLOPT_REFERER,'');
	curl_setopt($curl,CURLOPT_USERAGENT,'okhttp/3.8.1');
	$post= curl_exec($curl);
	curl_close($curl);
	$arr = json_decode($post, true);
// Access values from the associative array

$jnsb=$arr["_key"];
if($jnsb!=null){
//{echo'{"key":'.$arr["_key"].', "uid":'.$arr["user"]["userID"].'}';

$userMsg=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/2.1?_key=".$jnsb."&user_id=".$arr["user"]["userID"]);
$user=json_decode($userMsg,true);
$name=$user["nick"];
$returnJson=json_decode($post,true);
echo $msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];




}
//顶帖代码
//获取后缀


//获取
  
 echo"<br>回复了ID为". $pid=$_GET["uid"];//最新帖子ID
 //执行点赞


  //  $gzdf = "http://floor.huluxia.com/post/praise/ANDROID/2.1?platform=2&gkey=000000&app_version=4.1.1.2.2&versioncode=318&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=
//".$pid;
 //  echo "返回信息".$gzgzgz4 = file_get_contents($gzdf);
   
echo"的帖子";  
$postJson=file_get_contents("http://floor.huluxia.com/post/detail/ANDROID/2.3?post_id=".$pid);
$postArray=json_decode($postJson,true);
$title=$postArray["post"]["title"];


$file = file("jndt.txt");
//随机读取一行
$arr  = mt_rand( 0, count( $file ) - 1 );
echo"<br>回复内容:";
echo$html  = trim($file[$arr],"\n");

$file = file("jnhz.txt"); 
$arr  = mt_rand( 0, count( $file ) - 1 );
echo$content  = trim($file[$arr],"\n");
  
   // $hulu=$post["posts"][0]["user"]["credits"];//葫芦数
    
        $url2="http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.0.7&versioncode=20141436&market_id=floor_huluxia&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00-%5Bi%5D866934037372573-%5Bs%5D89861119147385482175&post_id=".$pid."&comment_id=0&text=".$html."".$content."&patcha=&images=&remindUsers=";
 // echo  file_get_contents($url2);
    $curl = curl_init();


$ip_long = array(
       array('607649792', '608174079'), //36.56.0.0-36.63.255.255
       array('1038614528', '1039007743'), //61.232.0.0-61.237.255.255
       array('1783627776', '1784676351'), //106.80.0.0-106.95.255.255
       array('2035023872', '2035154943'), //121.76.0.0-121.77.255.255
       array('2078801920', '2079064063'), //123.232.0.0-123.235.255.255
       array('-1950089216', '-1948778497'), //139.196.0.0-139.215.255.255
       array('-1425539072', '-1425014785'), //171.8.0.0-171.15.255.255
       array('-1236271104', '-1235419137'), //182.80.0.0-182.92.255.255
       array('-770113536', '-768606209'), //210.25.0.0-210.47.255.255
       array('-569376768', '-564133889'), //222.16.0.0-222.95.255.255
   );
   $rand_key = mt_rand(0, 9);
   $ip= long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
$header = array("Connection: Keep-Alive","Accept: text/html, application/xhtml+xml, */*", "Pragma: no-cache", "Accept-Language: zh-Hans-CN,zh-Hans;q=0.8,en-US;q=0.5,en;q=0.3","User-Agent: okhttp/3.8.1");

	curl_setopt($curl,CURLOPT_URL,$url2);
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($curl,CURLOPT_CONNECTTIMEOUT,10);
	curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
	curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
	//curl_setopt($curl,CURLOPT_HTTPHEADER,['X-FORWARDED-FOR:164.89.81.12','CLIENT-IP:164.89.81.12']);
	curl_setopt($curl,CURLOPT_REFERER,'');
	curl_setopt($curl,CURLOPT_USERAGENT,'okhttp/3.8.1');
	$post= curl_exec($curl);
	curl_close($curl);
	$arr = json_decode($post, true);
// Access values from the associative array
    file_put_contents("pid2.txt",$pid);
  
  
  //获取列表
$post=("http://floor.huluxia.com/comment/create/list/ANDROID/4.1.8?user_id=".$uid."&start=0&count=20&platform=2&gkey=000000&app_version=4.2.0.7&versioncode=20141481&market_id=floor_web&_key=".$key."&phone_brand_type=OP"); 
    $curl = curl_init();


$ip_long = array(
       array('607649792', '608174079'), //36.56.0.0-36.63.255.255
       array('1038614528', '1039007743'), //61.232.0.0-61.237.255.255
       array('1783627776', '1784676351'), //106.80.0.0-106.95.255.255
       array('2035023872', '2035154943'), //121.76.0.0-121.77.255.255
       array('2078801920', '2079064063'), //123.232.0.0-123.235.255.255
       array('-1950089216', '-1948778497'), //139.196.0.0-139.215.255.255
       array('-1425539072', '-1425014785'), //171.8.0.0-171.15.255.255
       array('-1236271104', '-1235419137'), //182.80.0.0-182.92.255.255
       array('-770113536', '-768606209'), //210.25.0.0-210.47.255.255
       array('-569376768', '-564133889'), //222.16.0.0-222.95.255.255
   );
   $rand_key = mt_rand(0, 9);
   $ip= long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
$header = array("Connection: Keep-Alive","Accept: text/html, application/xhtml+xml, */*", "Pragma: no-cache", "Accept-Language: zh-Hans-CN,zh-Hans;q=0.8,en-US;q=0.5,en;q=0.3","User-Agent: okhttp/3.8.1");

	curl_setopt($curl,CURLOPT_URL,$post);
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($curl,CURLOPT_CONNECTTIMEOUT,10);
	curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
	curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
	//curl_setopt($curl,CURLOPT_HTTPHEADER,['X-FORWARDED-FOR:164.89.81.12','CLIENT-IP:164.89.81.12']);
	curl_setopt($curl,CURLOPT_REFERER,'');
	curl_setopt($curl,CURLOPT_USERAGENT,'okhttp/3.8.1');
	$post= curl_exec($curl);
	curl_close($curl);
              $post=json_decode($post,true);
           $text=$post["comments"][0]["text"]; 
                $my_cid=$post["comments"][0]["commentID"];   
          if($_GET["uid"]！="否"){             
                           //删除评论
                           $sc="http://floor.huluxia.com/comment/destroy/ANDROID/2.0?_key=".$key."&comment_id=".$my_cid."&platform=2&gkey=000000&app_version=4.2.0.7&versioncode=20141481&market_id=floor_web&phone_brand_type=OP";
$curl = curl_init();


$ip_long = array(
       array('607649792', '608174079'), //36.56.0.0-36.63.255.255
       array('1038614528', '1039007743'), //61.232.0.0-61.237.255.255
       array('1783627776', '1784676351'), //106.80.0.0-106.95.255.255
       array('2035023872', '2035154943'), //121.76.0.0-121.77.255.255
       array('2078801920', '2079064063'), //123.232.0.0-123.235.255.255
       array('-1950089216', '-1948778497'), //139.196.0.0-139.215.255.255
       array('-1425539072', '-1425014785'), //171.8.0.0-171.15.255.255
       array('-1236271104', '-1235419137'), //182.80.0.0-182.92.255.255
       array('-770113536', '-768606209'), //210.25.0.0-210.47.255.255
       array('-569376768', '-564133889'), //222.16.0.0-222.95.255.255
   );
   $rand_key = mt_rand(0, 9);
   $ip= long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
$header = array("Connection: Keep-Alive","Accept: text/html, application/xhtml+xml, */*", "Pragma: no-cache", "Accept-Language: zh-Hans-CN,zh-Hans;q=0.8,en-US;q=0.5,en;q=0.3","User-Agent: okhttp/3.8.1");

	curl_setopt($curl,CURLOPT_URL,$sc);
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($curl,CURLOPT_CONNECTTIMEOUT,10);
	curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
	curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
	//curl_setopt($curl,CURLOPT_HTTPHEADER,['X-FORWARDED-FOR:164.89.81.12','CLIENT-IP:164.89.81.12']);
	curl_setopt($curl,CURLOPT_REFERER,'');
	curl_setopt($curl,CURLOPT_USERAGENT,'okhttp/3.8.1');
	echo"删除评论返回信息".$post= curl_exec($curl);
	curl_close($curl);
	}
    $b=$i+1;
    echo"<br>已顶帖成功:".$b."个，共:".$c."个";

$urltz="pldt.php?id=".$b."&uid=".$_GET["uid"];
if($i+1<$c){
   $cd=1000*rand(5,12);
echo
<<<EOF
<br><br>PS:请耐心等待，顶帖比较慢是为了防止违规和不可控情况发生!
<script type="text/javascript">

　　setTimeout("window.location.href='$urltz'",$cd);

</script><a href="">若卡住可点此刷新</a>
EOF;
}else {
   $cd=1000*rand(5,12);
    echo"<br>顶帖完成，即将自动循环";
    $urltz="pldt.php?id=0"."&uid=".$_GET["uid"];
<<<EOF
<br><br>PS:请耐心等待，顶帖比较慢是为了防止违规和不可控情况发生!
<script type="text/javascript">

　　setTimeout("window.location.href='$urltz'",$cd);

</script><a href="">若卡住可点此刷新</a>
EOF;

<<<EOF
<br><br>PS:请耐心等待，顶帖比较慢是为了模仿人类!
EOF;
}
}
}


