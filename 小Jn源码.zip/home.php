<?php
$phoneNumber=$_COOKIE["phone"];
$password=$_COOKIE["key"];
$r=$_COOKIE["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];

switch($msg)
{
  case "账号或密码错误":
    echo '账号或密码错误！';
    break;
  case "参数不合法":
    echo '参数不合法！';
    break;
  case "账号不存在":
    echo '账号不存在';
    break;
  case "":
 
     
 $userMsg=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/2.1?_key=".$key."&user_id=".$uid);
$user=json_decode($userMsg,true);
$name=$user["nick"];
$userMsg=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/2.1?_key=".$key."&user_id=".$uid);
$user=json_decode($userMsg,true);

$tp=$user["avatar"];
echo
<<<EOF
【 $name 】
[ $uid ]
# $tp &

EOF;
   
   
        
   
   
    break;
}
?>