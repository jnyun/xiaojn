<?php
$gn=$_POST["gn"];

$phoneNumber=$_COOKIE["phone"];
$password=$_COOKIE["key"];
$r=$_COOKIE["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);

$uid=$returnJson["user"]["userID"];


    
  $phoneNumber3=$_POST['phone'];
$password3=md5($_POST['key'],false);
$r3=$_POST['key'];
$result3=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber3."&login_type=2&password=".$password3);
$returnJson3=json_decode($result3,true);
$msg3=$returnJson3["msg"];
if($msg3!=null)
{
    echo"批量管理账号或密码错误";
}
switch($msg3)
{
  
  case "":
       $filename='xiaojnroobots/'.$uid.'.txt';
      $ex=file_exists($filename);//检测文件存在与否
    
  
   


if($ex==1)
{
    
    if($_POST['name']==''|$_POST['phone']==''|$_POST['key']==''|$gn== '')
	{
		echo '请填写完整';
	}
	else
	{
$myfilert2 = fopen($filename, "r") or die("Unable to open file!");
$f2 = fread($myfilert2,filesize($filename));
fclose($myfilert2);
echo"批量管理已存在";

if(strpos($f2,$_POST["phone"]) == false){
    
$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $f2."\n");//写入旧内容
fwrite($myfile, $_POST['name']."\n");//写入名字
fwrite($myfile, $_POST['phone']."\n");//写入手机
fwrite($myfile, $_POST['key']."\n");//写入密码
fwrite($myfile, $gn);//写入功能
fclose($myfile);
echo"新建批量管理成功";
}


}
}

   else
{

$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $_POST['name']."\n");//写入名字
fwrite($myfile, $_POST['phone']."\n");//写入手机
fwrite($myfile, $_POST['key']."\n");//写入密码
fwrite($myfile, $gn);//写入功能
fclose($myfile);
echo '批量管理创建成功';

}

   

  break;
}

?>