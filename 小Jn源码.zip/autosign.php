<?php ob_start(); ?>
<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <!-- MDUI CSS -->
    <link rel="stylesheet" href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"/>
    
  </head>
  <body>
   

    <!-- MDUI JavaScript -->
    <script src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"></script>
  </body>
</html>
<div class="mdui-typo-display-2"><div class="mdui-center" style="width: 200px">
<?php
error_reporting(0);

$getCatJson=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/4.1.8?platform=2&gkey=000000&app_version=4.2.0.4.2&versioncode=20141472&market_id=floor_web&_key=".$_COOKIE["ekey"]."&device_code=%5Bd%5D16485814-230d-424c-8af1-fda8f42d1e25&phone_brand_type=UN&user_id=".$_COOKIE["uid"]);
$catArray=json_decode($getCatJson,true);
$cats=$catArray["msg"];
if($cats!=null){
echo '<script>window.alert("登录过期，请返回主页面重新登录");</script>';
}

$getCatJson=file_get_contents("http://floor.huluxia.com/category/list/ANDROID/2.0?platform=2&gkey=000000&app_version=4.2.0.4.2&versioncode=20141472&market_id=floor_web&_key="."&phone_brand_type=OP&is_hidden=1");

$catArray=json_decode($getCatJson,true);
$cats=$catArray["categories"];
$cats[count($cats)+1]["categoryID"] = 15;	//葫芦山
$cats[count($cats)+1]["categoryID"] = 34;	//审核部
$cats[count($cats)+1]["categoryID"] = 94;	//三楼活动
$cats[count($cats)+1]["categoryID"] = 84;	//三楼精选
$cats[count($cats)+1]["categoryID"] = 69;	//优秀资源
$cats[count($cats)+1]["categoryID"] = 67;	//MC帖子
$cats[count($cats)+1]["categoryID"] = 68;	//资源审核

if($_GET["jn"]==null)
{
$catOid=0;
Header("Location:/autosign.php?jn=0");ob_end_flush();
}else{
    if($_GET["jn"]<count($cats))
    {
    $catOid=$_GET["jn"]+1;
    $cd=0.1*rand(5,12);
 echo'<meta http-equiv="refresh" content="'.$cd.';url=/autosign.php?jn='.$catOid.' "> ';

echo'<div class="mdui-spinner mdui-spinner-colorful"></div>';
 echo"正在高仿人类速度以随机速度签到<br>已签到:".$catOid."个<br>共:".count($cats)."个";
 $wl=100*$catOid/count($cats);
 echo <<<EOF
<div class="mdui-progress">
  <div class="mdui-progress-determinate" style="width:  $wl%;"></div>
</div>
EOF;
}else{
echo <<<EOF
<i class="mdui-icon material-icons">&#xe5ca;</i>
EOF;
echo"已全部签到完成<br>请不要理我后面那个破玩意说什么参数不能为空→";}
{
$cid=$cats[$catOid]["categoryID"];
$t=(int)(microtime(true)*1000);
 $txt="cat_id".$cid."time".$t."fa1c28a5b62e79c3e63d9030b6142e4b";
//写入
   $filename = 'sign.txt';
 
   $fp= fopen($filename, "w");
 
   $len = fwrite($fp, $txt);
 
   fclose($fp);
//读取
$myfile = fopen("sign.txt", "r") or die("Unable to open file!");
$sign=fread($myfile,filesize("sign.txt"));
fclose($myfile);
$sign = md5($sign);

function send_post($url, $post_data) {
 
  $postdata = http_build_query($post_data);
  $options = array(
    'http' => array(
        "Host"=>"floor.huluxia.com",
      'method' => 'POST',
      'Content-type' => 'application/x-www-form-urlencoded',
      'content' => $postdata,
      "User-Agent"=>'okhttp/3.8.1',
      "Accept-Encoding"=>"identity",
      "Content-Length"=>'37',
      'timeout' => 1 * 5 // 超时时间（单位:s）
    )
  );
  $context = stream_context_create($options);
  $result = file_get_contents($url, false, $context);
  
$arr = json_decode($result, true);
// Access values from the associative array
  
 	$arr = json_decode($result, true);
 	 $msg=$arr["status"];
 	  $msg2=$arr["msg"];
 	 if($msg=="1"){echo"<br>当前板块签到成功";}else{echo$msg2;}
 
  return $result;
}
 
//使用方法：GET本JnAPI接口两参数就完事了，分别是phone和key
$post_data = array(
"sign"=>$sign
);

send_post("http://floor.huluxia.com/user/signin/ANDROID/4.1.8?platform=2&gkey=000000&app_version=4.2.0.5&versioncode=20141475&market_id=floor_web&_key=".$_COOKIE["ekey"]."&phone_brand_type=OP&cat_id=".$cid."&time=".$t,$post_data);


}
}
?>
