	<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
<!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    /><!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
  	<!--必要样式-->
	<link rel="stylesheet" href="css/naranja.min.css">
</head>
<body>
	  <div class="mdui-tab mdui-tab-full-width" id="example4-tab">
    <a href="#example4-tab1" class="mdui-ripple">功能面板</a>
    <a href="#example4-tab2" class="mdui-ripple">回复自定义</a>
    <a href="#example4-tab3" class="mdui-ripple">常见问题</a>
  </div>
  <div id="example4-tab1" class="mdui-p-a-2">
 <ul class="mdui-list"> 
 
   <a href="/plgzgj.php">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-icon mdui-icon material-icons">note</i>
    <div class="mdui-list-item-content">批量关注</div>
  </li>
<a href="/plqggj.php">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-icon mdui-icon material-icons">note</i>
    <div class="mdui-list-item-content">批量取关</div>
  </li>
</a>
<a href="/pldzgj.php">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-icon mdui-icon material-icons">note</i>
    <div class="mdui-list-item-content">批量点赞</div>
  </li>
</a>
<a href="/plshlgj.php">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-icon mdui-icon material-icons">note</i>
    <div class="mdui-list-item-content">批量转移葫芦</div>
  </li>
</a>
<a href="/plhtxgj.php">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-icon mdui-icon material-icons">note</i>
    <div class="mdui-list-item-content">批量换头像</div>
  </li>
</a>
<a href="/pldtgj.php">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-icon mdui-icon material-icons">note</i>
    <div class="mdui-list-item-content">批量顶帖</div>
  </li>
 </ul>
  </div>
  <div id="example4-tab2" class="mdui-p-a-2">
    <ul class="mdui-list"> <a href="/yourck.php">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-icon mdui-icon material-icons">note</i>
    <div class="mdui-list-item-content">专属词库<p></p>（专属自定义回复，立即生效）</div>
  </li><a href="/yourckd.php">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-icon mdui-icon material-icons">note</i>
    <div class="mdui-list-item-content">专属词库设置<p></p></div>
  </li><a href="https://www.wjx.top/vm/mLtandD.aspx">
<li class="mdui-list-item mdui-ripple">
   <i class="mdui-list-item-icon mdui-icon material-icons">data_usage</i>
    <div class="mdui-list-item-content">自定义批量管理回复</div>
  </li>
  </ul></a>
    
  </div>
  <div id="example4-tab3" class="mdui-p-a-2">
    <p>下次也不一定写</p>
    
  </div>
</div>

<script>
  var tab = new mdui.Tab('#example4-tab');
  document.getElementById('example-4').addEventListener('open.mdui.dialog', function () {
    tab.handleUpdate();
  });
</script>
	<div class="container">
		<div class="row" style="padding:2em 0">
			<div class="col-md-2">
		
<div style="margin: 0 auto; width: 0%; position: fixed; bottom: 5px; height: 100％; font-size: 0; line-height: 0; z-index: 100; text-align: left;">

	
		</div></div>
