

<!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    /><!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes"/>
<style>
.center
{
text-align: center;
margin: auto;
}
input
{
width:80%;
height:30px;
}
button
{
width: 80%;
height: 30px;
}
</style>
</head>
<body>
<div class="center">
<p>回复间隔(单位:秒)</p>
<form action="/xiaojn666.php" method="get">
<input type="text" name="t" placeholder="输入间隔" /><br><br>

<button type="submit" class="mdui-btn mdui-btn-raised">开始运行</button>
</form>
<p>请不要退出页面，退出则停止运行</p>







<?php
//需要参数phone，key
ini_set("display_errors","off");
if($_GET["keyj"]!=null)
{
setrawcookie("key2",$_GET["keyj"],time()+2592);
   setrawcookie("phone2",$_GET["phone"],time()+2592);
   header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");//内容过期时间 强制浏览器去服务器去获取数据 而不是从缓存中读取数据
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");//标记内容最后修改时间
header("Cache-Control: no-store, no-cache, must-revalidate");//强制不缓存
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");//禁止本页被缓存
header("Access-Control-Allow-Origin: *"); // Support CORS
}
