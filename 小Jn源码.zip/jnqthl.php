<html lang="zh-cmn-Hans">
  <head>
      <meta http-equiv="refresh" content="<?php echo$_GET["t"];?>">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

<!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    /><!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
    
    
    
    
    <div class="mdui-card">

  <!-- 卡片头部，包含头像、标题、副标题 -->
  <div class="mdui-card-header">
    <img class="mdui-card-header-avatar" src="static/picture/hill.jpg"/>
    <div class="mdui-card-header-title">小Jn批量管理前端框架</div>
    <div class="mdui-card-header-subtitle">运行中</div>
  </div>

  <!-- 卡片的媒体内容，可以包含图片、视频等媒体内容，以及标题、副标题 -->
  <div class="mdui-card-media">
    <img src="static/picture/hill.jpg"/>

    <!-- 卡片中可以包含一个或多个菜单按钮 -->
    

  <!-- 卡片的标题和副标题 -->
  <div class="mdui-card-primary">
    <div class="mdui-card-primary-title">欢迎使用小Jn葫芦侠批量管理</div>
    <div class="mdui-card-primary-subtitle">其他功能</div>
  </div>

  <!-- 卡片的内容 -->
  <div class="mdui-card-content"></div>

  <!-- 卡片的按钮 -->
  <div class="mdui-card-actions">
    <button class="mdui-btn mdui-ripple">运行中</button>
    <button class="mdui-btn mdui-ripple">乞讨葫芦</button>
 </div>

</div>

    <div class="mdui-panel-item mdui-panel-item-open">
    <div class="mdui-panel-item-header">运行日志</div>
    <div class="mdui-panel-item-body">
      <?php

//需要参数phone，key
ini_set("display_errors","off");

if($_COOKIE["ekey"]==null){echo "未登录";}else {
//乞讨葫芦

  $url="http://floor.huluxia.com/post/list/ANDROID/2.1?platform=2&gkey=000000&app_version=4.0.0.7&versioncode=20141436&market_id=floor_huluxia&_key=".$_COOKIE["ekey"]."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00-%5Bi%5D866934037372573-%5Bs%5D89861119147385482175&start=0&count=20&cat_id=2&tag_id=0&sort_by=1";
 $post=file_get_contents($url);
  $post=json_decode($post,true);
 echo"回复了ID为". $pid=$post["posts"][0]["postID"];//最新帖子ID
 //执行点赞
$key=$_COOKIE["ekey"];
    $gzdf = "http://floor.huluxia.com/post/praise/ANDROID/2.1?platform=2&gkey=000000&app_version=4.1.1.2.2&versioncode=318&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=
".$pid;
   echo "返回信息".$gzgzgz4 = file_get_contents($gzdf);
   
echo"的帖子";  
    

   //获取一言
$file = file("pl.txt");
//随机读取一行
$arr  = mt_rand( 0, count( $file ) - 1 );
echo"<br>回复内容:";
$content  = trim($file[$arr],"\n");

  if($pid==file_get_contents("pid.txt"))
  {
    echo "已回复";
  }
  else
  {
  $fp= fopen("pid.txt","w");
 
   $len = fwrite($fp, $pid);
 
   fclose($fp);
 
    $hulu=$post["posts"][0]["user"]["credits"];//葫芦数
    echo $hulu.$content;
    if($hulu=="0"){echo"你遇上了一个一个葫芦都没有的穷逼，本次不回复";}else{
    $url="http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.0.7&versioncode=20141436&market_id=floor_huluxia&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00-%5Bi%5D866934037372573-%5Bs%5D89861119147385482175&post_id=".$pid."&comment_id=0&text=".$hulu.$content ."&patcha=&images=,&remindUsers=";
   echo file_get_contents($url);
              $post=file_get_contents("http://floor.huluxia.com/comment/create/list/ANDROID/4.1.8?user_id=".$_COOKIE["uid"]."&start=0&count=20&platform=2&gkey=000000&app_version=4.2.0.7&versioncode=20141481&market_id=floor_web&_key=".$_COOKIE["ekey"]."&phone_brand_type=OP"); 
              $post=json_decode($post,true);
           echo$text=$post["comments"][0]["text"]; 
                echo $my_cid=$post["comments"][0]["commentID"];       
                if(strpos($text,'葫芦') !== false)
{

         echo file_get_contents("http://floor.huluxia.com/comment/destroy/ANDROID/2.0?_key=".$_COOKIE["ekey"]."&comment_id=".$my_cid."&platform=2&gkey=000000&app_version=4.2.0.7&versioncode=20141481&market_id=floor_web&phone_brand_type=OP");
    }
  }}}