	<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
<!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    /><!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
  	<!--必要样式-->
	<link rel="stylesheet" href="css/naranja.min.css">
</head>

<div class="mdui-tab mdui-tab-full-width" id="example4-tab">
    <a href="#example4-tab1" class="mdui-ripple">友链列表</a>
   
     <a href="#example4-tab4" class="mdui-ripple">大佬列表</a>
  </div>
   <div id="example4-tab4" class="mdui-p-a-2">
    <p>大佬列表（点击可以关注）</p>
    <ul class="mdui-list">
         <a href="/gzapi.php?uid=1478397"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="http://cdn.u1.huluxia.com/g4/M02/14/47/rBAAdmDyrdOAHGeyAAE3Ku3HLlQ462.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">猫</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>人类的本质</div>
    </div>
    </a>
  </li> 
          <a href="/gzapi.php?uid=18925902"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="hm.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">远方一抹晚霞</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>我就是一名普普通通的白嫖怪呀！</div>
    </div>
    </a>
  </li> 
  
  
   <a href="/gzapi.php?uid=7642103"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="http://cdn.u1.huluxia.com/g4/M01/0B/B4/rBAAdmDteRWARHxPAACvzVIalPY598.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">汐倩</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>但愿日子清静，无时无刻白嫖！</div>
    </div>
    </a>
  </li> 
  
   <a href="/gzapi.php?uid=18821624"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="mx.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">梦醒</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>一只没有梦想的咸鱼</div>
    </div>
    </a>
  </li> 
      <a href="/gzapi.php?uid=128335"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="ouh.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">欧皇</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span> - 我就是一歌手</div>
    </div>
    </a>
  </li> 
        <a href="/gzapi.php?uid=7183021"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="mchj.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">MC滑稽</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text">技术</span> - 我是MC滑稽</div>
    </div>
    </a>
  </li>
  <a href="/gzapi.php?uid=24867356"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="http://zhi.52msr.cn/logo.png"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">至白</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>至白云http://zhi.52msr.cn/</div>
    </div>
    </a>
  </li> 
         <a href="/gzapi.php?uid=16189034"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="qf.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">穷枫</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text">破解</span> - 逆向小白 葫芦侠萌新</div>
    </div>
    </a>   <a href="/gzapi.php?uid=22271284"
  <li class="mdui-divider-inset mdui-m-y-0"></li>
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="http://cdn.u1.huluxia.com/g3/M03/4C/5F/wKgBOV6ew4qAJxrzAAIotvt_WwA255.jpg"/></div>
   <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">水(⊙o⊙)啊</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>天若有情天亦老，人间正道是沧桑。</div>
    </div>
  </li></a>
   </li> <a href="/gzapi.php?uid=12132089"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="avatar1.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">滑稽MC</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text">MC,技术</span> - 葫芦侠在线版开发</div>
    </div>
    </a>
  </li> <a href="/gzapi.php?uid=12699242"
  <li class="mdui-divider-inset mdui-m-y-0"></li>
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="avatar2.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">小滑稽</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text">我是小滑稽呀</span> - 技术大佬</div>
    </div>
  </li> <a href="/gzapi.php?uid=12957261"
  <li class="mdui-divider-inset mdui-m-y-0"></li>
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="avatar3.jpg"/></div>
   <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">Jn</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>经常出一些高阶技术教程!</div>
    </div>
  </li></a>
   </li> <a href="/gzapi.php?uid=17835996"
  <li class="mdui-divider-inset mdui-m-y-0"></li>
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="avatar4.jpg"/></div>
   <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">无语</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>只摸鱼不干正事的老帅批</div>
    </div>
  </li></a>
   <a href="/gzapi.php?uid=5131563"
  <li class="mdui-divider-inset mdui-m-y-0"></li>
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="avatar5.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">萝卜</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text">这是一种蔬菜</span></div>
    </div>
  </li> 
   <a href="/gzapi.php?uid=15675447"
  <li class="mdui-divider-inset mdui-m-y-0"></li>
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="avatar6.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">云猫</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text">貌似可以白嫖，我能上嘛</span></span></div>
    </div>
  </li> 
  </a>
   <a href="/gzapi.php?uid=23436195"
  <li class="mdui-divider-inset mdui-m-y-0"></li>
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="avatar7.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">小猪猪520</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text">我是一条咸猪，不要管我</span></div>
    </div>
  </li> </a>
</ul>
    
  </div>
  <div id="example4-tab1" class="mdui-p-a-2">
   欢迎光临与我们添加友链，让我们共同进步!
   <br>PS:添加友链不要钱，友链内的内容并非小Jn官方提供，请自行辨别信息!!!<h3>友链：</h3>
    <ul class="mdui-list">
           <a href="https://xding.top/"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="https://xding.top/face.png"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">小丁的博客
</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>一个神秘的大宝贝...
</div>
    </div>
    </a>
  </li>  <a href="https://www.zllwl.com"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="http://q1.qlogo.cn/g?b=qq&nk=3549518275&s=640"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">紫罗兰博客

</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>一个个人博客

</div>
    </div>
    </a>
  </li> 
  <a href="http://zzhlw.tk/"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="https://img02.sogoucdn.com/app/a/100520146/ad83949a5f517582e6b7ef9b097be7c5"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">猪猪社区

</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>一只猪的小窝

</div>
    </div>
    </a>
  </li> 
          <a href="https://www.yhdzz.cn"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="https://www.yhdzz.cn/wp-content/uploads/2020/07/2020070520290284.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">小满1221的博客
</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>芸芸众生的一个小白
</div>
    </div>
    </a>
     <a href="http://www.yexinghu.top"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="https://s3.jpg.cm/2021/07/15/IdvkDz.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">穷枫的小窝
</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>财尽缘散
</div>
    </div>
    </a>
  </li> 
  
  </li> 
         <a href="http://jixiejidiguan.top/"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="http://q1.qlogo.cn/g?b=qq&nk=3549518275&s=640"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">JIXIEJIDIGUAN

</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>一个静态超多bog加载速度非常卡的网页！滑稽

</div>
    </div>
    </a>
  </li> 
  
  </ul>
  </div>
  
  
<script>
  var tab = new mdui.Tab('#example4-tab');
  document.getElementById('example-4').addEventListener('open.mdui.dialog', function () {
    tab.handleUpdate();
  });
</script>
	<div class="container">
		<div class="row" style="padding:2em 0">
			<div class="col-md-2">
		
<div style="margin: 0 auto; width: 0%; position: fixed; bottom: 5px; height: 100％; font-size: 0; line-height: 0; z-index: 100; text-align: left;">

	
		</div></div>
