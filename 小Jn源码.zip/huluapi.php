<?php ob_start(); ?>
<?php
error_reporting(0);
if($_COOKIE["ekey"]==null)
{
 echo '<script>window.alert("未登录！");</script>';
 
 Header("Location: /login.php");
  
 }
$getCatJson=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/4.1.8?platform=2&gkey=000000&app_version=4.2.0.4.2&versioncode=20141472&market_id=floor_web&_key=".$_COOKIE["ekey"]."&device_code=%5Bd%5D16485814-230d-424c-8af1-fda8f42d1e25&phone_brand_type=UN&user_id=".$_COOKIE["uid"]);
$catArray=json_decode($getCatJson,true);
$cats=$catArray["msg"];
if($cats==null){
$key=$_COOKIE["ekey"];
$uid=$_COOKIE["uid"];

setrawcookie("hulu",$_COOKIE["hulu"]+5,time()+259200);
ob_end_flush();
echo"已送葫芦:".$h=$_COOKIE["hulu"]+5;
echo"目标葫芦:".$z=$_GET["hulu"];
if($_GET["hulu"]>$_COOKIE["hulu"]+5){
echo <<<EOF
状态:正在送葫芦，系统返回:
<meta http-equiv="refresh" content="10">

EOF;

}
else
{
    echo <<<EOF
    状态:本次赠送完成，系统返回:
EOF;

}

//随机原因
$file = file("hlyy.txt");
//随机读取一行
$arr  = mt_rand( 0, count( $file ) - 1 );
echo"随机原因:";
echo$sjyy  = trim($file[$arr],"\n");


$floor=$_GET["floor"];//楼层，为空则为主帖

$pid=$_GET["pid"];//帖子id

if($key!=null)
{
  if($pid!=null)
  {
    $post=file_get_contents("http://floor.huluxia.com/post/detail/ANDROID/2.3?post_id=".$pid."&page_size=500");
    $post=json_decode($post,true);
    if($floor==null)
    {
     echo file_get_contents("http://floor.huluxia.com/credits/transfer/ANDROID/2.0?_key=".$key."&post_id=".$pid."&type_id=1&isadmin=0&score=5&score_txt=".$sjyy);
    }
    else
    {
      $cid=$post["comments"][$floor-1]["commentID"];
     echo file_get_contents("http://floor.huluxia.com/credits/transfer/ANDROID/2.0?_key=".$key."&post_id=".$cid."&type_id=2&isadmin=0&score=5&score_txt=".$sjyy);
    }
    sleep(1);
    $my_cid=$post["comments"][count($post["comments"])-1]["commentID"];
    file_get_contents("http://floor.huluxia.com/comment/destroy/ANDROID/2.0?_key=".$key."&comment_id=".$my_cid);
     $my_cid2=$post["comments"][count($post["comments"])]["commentID"];
    file_get_contents("http://floor.huluxia.com/comment/destroy/ANDROID/2.0?_key=".$key."&comment_id=".$my_cid2);
    
  }
  else
  {
    echo "帖子ID不能为空！";
  }
}
else
{
  echo "key不能为空！";
}}
?>