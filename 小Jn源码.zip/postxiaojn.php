<?php
function post($url){
$data = array(
    'zh'=>'zh',
    'mm'=>"mm"
    ); 
$query = http_build_query($data); 
$options['http'] = array(
     'timeout'=>60,
     'method' => 'POST',
     'header' => 'Content-type:application/x-www-form-urlencoded',
     'content' => $query
    );
$context = stream_context_create($options);
$result = file_get_contents($url, false, $context);
echo $result;
}
?>