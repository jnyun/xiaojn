<!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>小Jn——活动添加</title>
	<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

<!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    />
        <body class="mdui-appbar-with-toolbar">
  <div class="mdui-appbar mdui-appbar-fixed mdui-appbar-scroll-hide">
    <div class="mdui-toolbar mdui-color-theme">
  <a href="javascript:window.history.back();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">keyboard_arrow_left</i></a>
  <span class="mdui-typo-title">小Jn</span>
  <div class="mdui-toolbar-spacer"></div>
  
  

  <a href="javascript:location.reload();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">refresh</i></a>
<button class="mdui-btn mdui-btn-icon" mdui-menu="{target:'#main-menu'}"><i class="mdui-icon material-icons">more_vert</i></button>

<ul class="mdui-menu" id="main-menu">

              	<li class="mdui-menu-item" >
                	<a href="/tool.php" class="mdui-ripple">首页</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/jqrcz.php" class="mdui-ripple">批量管理</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/box.php" class="mdui-ripple">工具箱</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/site.php" class="mdui-ripple">分站</a>
              	</li>
            </ul>
  		</div>
	</div>
		<script src="./js/mdui.min.js"></script> 	  <script>     if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");      document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     );  </script><p id="switch-theme">>点此切换黑白</p> <script>      if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");           document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     ); </script><script type="text/javascript" src="https://s9.cnzz.com/z_stat.php?id=1279812358&web_id=1279812358"></script></a>               	</li>             </ul>   		</div> 	</div> 	
	<script src="./js/jquery.min.js"></script>
	<script type="text/javascript" charset="utf-8">
	  $(window).scroll(function(){
	    var scrollTop = $(window).scrollTop();
	   if (scrollTop < 100) {
	      $(".mdui-APPbar").removeClass("mdui-color-theme");
          $(".mdui-APPbar").addClass("mdui-text-color-black");
          $(".mdui-APPbar").removeClass("mdui-text-color-white")
	   } else {
	      $(".mdui-APPbar").addClass("mdui-text-color-white");
	      $(".mdui-APPbar").addClass("mdui-color-theme");
	      $(".mdui-APPbar").removeClass("mdui-text-color-black");
	   }
	  });
	</script>
  </head>
  <div class="mdui-ripple">
<div class="mdui-panel-item mdui-panel-item-open">
    <div class="mdui-panel-item-header">小Jn</div>
    <div class="mdui-panel-item-body">
      
      <a href="/jc.php">点击查看功能介绍</a>
    </div>
  </div>
<h1>
<?php



if($_GET["zqhf"]!=null)
{
    $gn=$gn."1";
}
if($_GET["cwhf"]!=null)
{
    $gn=$gn."2";
}
if($_GET["shl"]!=null)
{
    $gn=$gn."3";
}

$phoneNumber=$_COOKIE["phone"];
$password=$_COOKIE["key"];
$r=$_COOKIE["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);

$uid=$returnJson["user"]["userID"];


    
  $phoneNumber3=$_GET['phone'];
$password3=md5($_GET['key'],false);
$r3=$_GET['key'];
$result3=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber3."&login_type=2&password=".$password3);
$returnJson3=json_decode($result3,true);
$msg3=$returnJson3["msg"];
if($msg3!=null)
{
    echo"活动处理批量管理账号或密码错误";
}
switch($msg3)
{
  
  case "":
       $filename='hd/'.$uid.'.txt';
      $ex=file_exists($filename);//检测文件存在与否
    
  
   


if($ex==1)
{
    
    if($_GET['name']==''|$_GET['phone']==''|$_GET['key']==''|$gn== '')
	{
		echo '<br>请填写完整';
	}
	else
	{
$myfilert2 = fopen($filename, "r") or die("Unable to open file!");
$f2 = fread($myfilert2,filesize($filename));
fclose($myfilert2);
echo"<br>最高测试权限存在";

if(strpos($f2,$_GET["name"]) == false){
    
$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $f2."\n");//写入旧内容
fwrite($myfile, $_GET['name']."\n");//写入uid
fwrite($myfile, $_GET['phone']."\n");//写入手机
fwrite($myfile, $_GET['key']."\n");//写入密码
fwrite($myfile, $gn."\n");//写入功能（正确回复1，错误回复2，送葫芦3）
fwrite($myfile, $_GET['da']."\n");//写入答案
fwrite($myfile, $_GET['why']."\n");//写入送葫芦原因
fwrite($myfile, $_GET['geshu']);//写入送葫芦个数
fclose($myfile);
echo"<br>新建活动成功";
}


}
}

   else
{

$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $_GET['name']."\n");//写入uid
fwrite($myfile, $_GET['phone']."\n");//写入手机
fwrite($myfile, $_GET['key']."\n");//写入密码
fwrite($myfile, $gn."\n");//写入功能（正确回复1，错误回复2，送葫芦3）
fwrite($myfile, $_GET['da']."\n");//写入答案
fwrite($myfile, $_GET['why']."\n");//写入送葫芦原因
fwrite($myfile, $_GET['geshu']);//写入送葫芦个数
fclose($myfile);
echo '<br>活动创建成功';

}

   

  break;
}

?>
<a href="/hdjqrcz.php"<div class="mdui-center" style="width: 200px">点此返回活动管理页面</div></a>