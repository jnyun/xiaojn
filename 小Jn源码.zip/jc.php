<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    />
    <title>小Jn批量管理功能介绍</title>
  </head>
  <body>
        <body class="mdui-appbar-with-toolbar">
  <div class="mdui-appbar mdui-appbar-fixed mdui-appbar-scroll-hide">
    <div class="mdui-toolbar mdui-color-theme">
  <a href="javascript:window.history.back();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">keyboard_arrow_left</i></a>
  <span class="mdui-typo-title">小Jn</span>
  <div class="mdui-toolbar-spacer"></div>
  
  

  <a href="javascript:location.reload();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">refresh</i></a>
<button class="mdui-btn mdui-btn-icon" mdui-menu="{target:'#main-menu'}"><i class="mdui-icon material-icons">more_vert</i></button>

<ul class="mdui-menu" id="main-menu">

              	<li class="mdui-menu-item" >
                	<a href="/tool.php" class="mdui-ripple">首页</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/jqrcz.php" class="mdui-ripple">批量管理</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/box.php" class="mdui-ripple">工具箱</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/site.php" class="mdui-ripple">分站</a>
              	</li>
            </ul>
  		</div>
	</div>
		<script src="./js/mdui.min.js"></script> 	  <script>     if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");      document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     );  </script><p id="switch-theme">>点此切换黑白</p> <script>      if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");           document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     ); </script><script type="text/javascript" src="https://s9.cnzz.com/z_stat.php?id=1279812358&web_id=1279812358"></script></a>               	</li>             </ul>   		</div> 	</div> 	
	<script src="./js/jquery.min.js"></script>
	<script type="text/javascript" charset="utf-8">
	  $(window).scroll(function(){
	    var scrollTop = $(window).scrollTop();
	   if (scrollTop < 100) {
	      $(".mdui-APPbar").removeClass("mdui-color-theme");
          $(".mdui-APPbar").addClass("mdui-text-color-black");
          $(".mdui-APPbar").removeClass("mdui-text-color-white")
	   } else {
	      $(".mdui-APPbar").addClass("mdui-text-color-white");
	      $(".mdui-APPbar").addClass("mdui-color-theme");
	      $(".mdui-APPbar").removeClass("mdui-text-color-black");
	   }
	  });
	</script>
	
<div class="mdui-ripple">

<ul class="mdui-list">
  
<div class="mdui-panel" mdui-panel>
  <div class="mdui-panel-item">
    <div class="mdui-panel-item-header">
      <div class="mdui-panel-item-title">批量管理</div>
      
      <div class="mdui-panel-item-summary">点击查看介绍</div>
      <i class="mdui-panel-item-arrow mdui-icon material-icons">keyboard_arrow_down</i>
    </div>
    
    <div class="mdui-panel-item-body">
<br>        各位大佬你们挂监控正常一点
<br>1.不要把多个网址粘到一个编辑框里去
<br>2.不要把监控间隔设置在30秒以内
<br>以下是我们的建议间隔
<br>1.自动回复最好30到60秒
<br>2.自动签到最好2小时一次，记得换算单位
<br>3.自动乞讨顶帖之类的，就跟自动回复差不多好了
<br>4.自动水帖，你至少设置个10分钟间隔吧，要不然频繁发不出去的
<br>5.自动卖关注和自动回复一样，起码要30到60秒
<br>谢谢合作!!!!!＼（〇_ｏ）／
 <div class="mdui-panel" mdui-panel>
  <div class="mdui-panel-item">
    <div class="mdui-panel-item-header">
      <div class="mdui-panel-item-title">我要关注/取关功能</div>
      <div class="mdui-panel-item-summary">点击查看介绍</div>
      <i class="mdui-panel-item-arrow mdui-icon material-icons">keyboard_arrow_down</i>
    </div>
    <div class="mdui-panel-item-body">
      <p>我要关注/取关功能介绍</p>
      <p>当对方回复"我要关注"/"不互关"，"不要"等关键词时
 </p> <p>自动关注/取关</p>
      <p>并发送"关注了，互关吗？"/"好的，取关了[滑稽][玫瑰]"评论</p>

      <div class="mdui-panel-item-actions">
        <button class="mdui-btn mdui-ripple" mdui-panel-item-close>关闭</button>
      
      </div>
    </div>
  </div>
  <div class="mdui-panel-item">
    <div class="mdui-panel-item-header">
      <div class="mdui-panel-item-title">签到功能</div>
      <i class="mdui-panel-item-arrow mdui-icon material-icons">keyboard_arrow_down</i>
    </div>
    <div class="mdui-panel-item-body">
      <p>触发"签到"关键词时会发葫芦，每天只可以签到一次</p>
      
     
      <div class="mdui-panel-item-actions">
        <button class="mdui-btn mdui-ripple" mdui-panel-item-close>关闭</button>
      
      </div>
    </div>
  </div>
  <div class="mdui-panel-item">
    <div class="mdui-panel-item-header">
      <div class="mdui-panel-item-title">涩图功能</div>
      <i class="mdui-panel-item-arrow mdui-icon material-icons">keyboard_arrow_down</i>
    </div>
    <div class="mdui-panel-item-body">
      <p>触发"涩图"关键词时会发涩图</p>
      
     
      <div class="mdui-panel-item-actions">
        <button class="mdui-btn mdui-ripple" mdui-panel-item-close>关闭</button>
      
      </div>
    </div>
  </div>
   <div class="mdui-panel-item">
    <div class="mdui-panel-item-header">
      <div class="mdui-panel-item-title">卖关注功能</div>
      <i class="mdui-panel-item-arrow mdui-icon material-icons">keyboard_arrow_down</i>
    </div>
    <div class="mdui-panel-item-body">
      <p>触发"被赠送葫芦"操作时会给予赠送人关注</p>
      <p>并回复“关注你了!”</p>
     
      <div class="mdui-panel-item-actions">
        <button class="mdui-btn mdui-ripple" mdui-panel-item-close>关闭</button>
      
      </div>
    </div>
  </div>
 <div class="mdui-panel-item">
    <div class="mdui-panel-item-header">
      <div class="mdui-panel-item-title">点赞功能</div>
      <i class="mdui-panel-item-arrow mdui-icon material-icons">keyboard_arrow_down</i>
    </div>
    <div class="mdui-panel-item-body">
      <p>触发"我要点赞"关键词时会给予点赞</p>
      <p>并回复“点赞了，有葫芦吗？”</p>
     
      <div class="mdui-panel-item-actions">
        <button class="mdui-btn mdui-ripple" mdui-panel-item-close>关闭</button>
      
      </div>
    </div>
  </div>
  <div class="mdui-panel-item">
    <div class="mdui-panel-item-header">
      <div class="mdui-panel-item-title">聊天功能</div>
      <i class="mdui-panel-item-arrow mdui-icon material-icons">keyboard_arrow_down</i>
    </div>
    <div class="mdui-panel-item-body">
      <p>小Jn自动回复批量管理介绍</p>
      <p>可以通过艾特召唤</p>
      <p>支持普通闲聊</p>
      <div class="mdui-panel-item-actions">
        <button class="mdui-btn mdui-ripple" mdui-panel-item-close>关闭</button>
      
      </div>
    </div>
  </div>

  <div class="mdui-panel-item">
    <div class="mdui-panel-item-header">
      <div class="mdui-panel-item-title">我要互关</div>
      <div class="mdui-panel-item-summary"></div>
      <div class="mdui-panel-item-summary"></div>
      <i class="mdui-panel-item-arrow mdui-icon material-icons">keyboard_arrow_down</i>
    </div>
    <div class="mdui-panel-item-body">
      <p>回复我要互关或是我要关注时
      <br>小Jn系统会自动判断对方是否关注自己
      <br>如果对方关注了自己
      <br>才会关注对方并回复已关注
      <br>反之则仅会回复请先关注不执行关注操作</p>
      
      <div class="mdui-panel-item-actions">
        <button class="mdui-btn mdui-ripple" mdui-panel-item-close>关闭</button>
      
      </div>
    </div>
  </div>
  <div class="mdui-panel-item">
    <div class="mdui-panel-item-header">
      <div class="mdui-panel-item-title">要广告费</div>
      <div class="mdui-panel-item-summary"></div>
      <div class="mdui-panel-item-summary"></div>
      <i class="mdui-panel-item-arrow mdui-icon material-icons">keyboard_arrow_down</i>
    </div>
    <div class="mdui-panel-item-body">
      <p>当对方评论存在广告二字时，自动取关并发送要广告费的信息</p>
      
      <div class="mdui-panel-item-actions">
        <button class="mdui-btn mdui-ripple" mdui-panel-item-close>关闭</button>
      
      </div>
    </div>
  </div>
  <div class="mdui-panel-item">
    <div class="mdui-panel-item-header">
      <div class="mdui-panel-item-title">顶帖功能</div>
      <i class="mdui-panel-item-arrow mdui-icon material-icons">keyboard_arrow_down</i>
    </div>
    <div class="mdui-panel-item-body">
      <p>自动获取泳池第一贴</p>
      <p>自动判断帖子类型</p>
      <p>发送符合帖子内容</p>
      <p>不建议与自动回复同时开启</p>
      <div class="mdui-panel-item-actions">
        <button class="mdui-btn mdui-ripple" mdui-panel-item-close>关闭</button>
      
      </div>
    </div>
  </div>
  <div class="mdui-panel-item-actions">
        <button class="mdui-btn mdui-ripple" mdui-panel-item-close>关闭</button>
      
      </div>
    </div>
  </div>
  <div class="mdui-panel" mdui-panel>
      <div class="mdui-panel-item">
    <div class="mdui-panel-item-header">
      <div class="mdui-panel-item-title">我的网站功能</div>
      <i class="mdui-panel-item-arrow mdui-icon material-icons">keyboard_arrow_down</i>
    </div>
    <div class="mdui-panel-item-body">
      <p>这个讲实话，我觉得没什么好说的</p>
      <p>全免费部署，不需要续费啥的，一键代建小Jn同款网站</p>
      <p>功能啥的与1.0正式版小Jn一样</p>
      <p>后台地址:域名/admin</p>
      <p>可以在后台操作自定义前端模板，支持自定义html</p>
      <p>可以设置收葫芦，实现无本收益</p>
      <p>数据统计让收益清晰可见，我们不收取任何手续费!</p>
      <div class="mdui-panel-item-actions">
        <button class="mdui-btn mdui-ripple" mdui-panel-item-close>关闭</button>
      
      </div>
    </div>
  </div>
<div class="mdui-panel-item">
    <div class="mdui-panel-item-header">
      <div class="mdui-panel-item-title">批量管理区别</div>
      <div class="mdui-panel-item-summary"></div>
      <div class="mdui-panel-item-summary"></div>
      <i class="mdui-panel-item-arrow mdui-icon material-icons">keyboard_arrow_down</i>
    </div>
    <div class="mdui-panel-item-body">
      <p>工具箱里面的批量管理和自定义批量管理有什么区别?</p>
      <p>在这里我们可以很坦白的告诉你，没有区别!</p>
      <p>但是非常明显的我们的那个批量管理比工具箱的那个更强大</p>
      <p>它支持后端监控，告别一直要挂前端的互困扰</p>
      <p>并且它还能自定义开启功能和关闭功能</p>
      <p>实现大号小号都能开批量管理!</p>
      
      <div class="mdui-panel-item-actions">
        <button class="mdui-btn mdui-ripple" mdui-panel-item-close>关闭</button>
      
      </div>
    </div>
  </div>
 <div class="mdui-panel-item">
    <div class="mdui-panel-item-header">
      <div class="mdui-panel-item-title">功能选择推荐</div>
      <div class="mdui-panel-item-summary"></div>
      <div class="mdui-panel-item-summary"></div>
      <i class="mdui-panel-item-arrow mdui-icon material-icons">keyboard_arrow_down</i>
    </div>
    <div class="mdui-panel-item-body">
      <p>很多人犹豫给批量管理选择功能</p>
      <p>到底开不开这个功能呢？</p>
      <p>那个功能看起来也不错</p>
      <p>所以这里给大家带来一期教程</p>
      <p>假如是大号的话，我们推荐只开我要关注，我要取关，我要广告费</p>
      <p>当然，我们比较推荐的是只开我要取关和我要广告费</p>
      <p>因为假如大号开自动回复的话，容易让人误会为你本人回复</p>
      <p>大号开了我要关注的话容易关注了一大堆不认识的人</p>
      <p>引起一些不必要的麻烦</p>
      <p>至于小号的话，我们建议全开，但一切以实际为准嘛，希望你们玩得愉快!</p>
      
      <div class="mdui-panel-item-actions">
        <button class="mdui-btn mdui-ripple" mdui-panel-item-close>关闭</button>
      
      </div>
    </div>
  </div>
  <div class="mdui-panel-item">
    <div class="mdui-panel-item-header">
      <div class="mdui-panel-item-title">小Jn怎么运营</div>
      <i class="mdui-panel-item-arrow mdui-icon material-icons">keyboard_arrow_down</i>
    </div>
    <div class="mdui-panel-item-body">
      <p>小Jn是亏钱的，一直</p>
      <p>因为所有功能都是免费的</p>
      <p>源码是公益开发小狗杂写的</p>
      <p>域名，服务器，技术支持都是大佬们免费提供的</p>
      <p>要是能接个广告或许能稳一点。。</p>
      <p>虽然知道结局如何，但希望能一直做下去</p>
      <p>希望大家多多赞助吧，感谢理解支持</p>
      <div class="mdui-panel-item-actions">
        <button class="mdui-btn mdui-ripple" mdui-panel-item-close>关闭</button>
      
      </div>
    </div>
  </div>
  
<h3>如何拥有小Jn?</h3>
<div class="mdui-panel" mdui-panel>

  <div class="mdui-panel-item">
    <div class="mdui-panel-item-header">第一种</div>
    <div class="mdui-panel-item-body">
      <p>点击添加批量管理按钮</p>
      <p>给你的批量管理命名</p>
      <p>输入批量管理账号密码</p>
      <p>选择你所需要的功能</p>
      <p>生成监控地址</p>
      <p>复制它</p>
      <p>百度免费监控网，或者用我们首页里的免费官方监控</p>
      <p>注册登录</p>
      <p>添加网址监控</p>
      <p>输入这个监控地址</p>
      <p>监控间隔即为回复间隔</p>
    </div>
  </div>

  <div class="mdui-panel-item">
    <div class="mdui-panel-item-header">第二种</div>
    <div class="mdui-panel-item-body">
      <p>使用API</p>
      <p>替换中文信息为你自己的</p>
      <p>使用免费监控网</p>
      <p>注册登录</p>
      <p>添加网址监控</p>
      <p>输入这个监控地址</p>
      <p>监控间隔即为回复间隔！建议不要短于10s!</p>
    </div>
  </div>
<h3>搭建自己的小Jn</h3>
  <div class="mdui-panel-item">
    <div class="mdui-panel-item-header">一步到位</div>
    <div class="mdui-panel-item-body">
      <p>1.点击分站</p>
      <p>一键部署</p>
       <p>2.点击源码</p>
      <p>下载源码，去买一个虚拟主机，上传，解压，绑定域名，访问安装，完成</p>
    </div>
  </div>


    <!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
  </body>
</html>