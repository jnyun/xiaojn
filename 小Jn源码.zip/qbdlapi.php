<?php
$a=file_get_contents("http://floor.huluxia.com/qq/login/ANDROID/2.1?platform=2&gkey=&device_code=&market_id=floor_web&app_version=&versioncode=&access_token=".$_GET["1"]."&openid=".$_GET["2"]);
$returnJson=json_decode($a,true);
$msg=$returnJson["msg"];
$uid=$returnJson["user"]["userID"];
$filename2='qb/'.$uid.'.txt';
$b=file($filename2);
$ex=file_exists($filename2);//检测文件存在与否
if($ex==1)
{
$phone=$b[0];
$key=$b[1];
echo<<<EOF
!$phone!($key)
EOF;
}
else {
    echo<<<EOF
    登录失败
EOF;
    
}