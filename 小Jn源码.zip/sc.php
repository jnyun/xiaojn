<?php

  ?><div style="height:100%;width:100%;background-color:#1fc8db;background-image:linear-gradient(141deg,#9fb8ad 0%,#1fc8db 51%,#2cb5e8 75%);color:white;opacity:0.95;text-align:center;margin:auto;color:#f3f3f3;font-size:50px;font-weight:550;">

<?php
$pl2=file_get_contents("http://floor.huluxia.com/comment/destroy/ANDROID/2.0?comment_id=".$_GET["cmid"]."&platform=2&gkey=000000&app_version=4.0.1.9.1&versioncode=309&market_id=tool_tencent&_key="
.$_COOKIE["ekey"]."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e");
$arr2 = json_decode($pl2,true);




//超级获取术
echo"JnAPI：";

$a=$arr2["msg"];//评论内容

if ($a==null) {
 echo"删除成功！";
}
if($a=="出错了，请联系客服")
{
    echo"请不要违规操作!";
}
if($a=="没有权限")
{
    echo"你忘了你只是一个凡人吗？";
}
?>

</div>
